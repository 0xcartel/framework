#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────
#  Bug Bounty Framework — Setup Script
#  يثبت كل الأدوات ويحدث config.yaml تلقائياً
# ─────────────────────────────────────────────────────────────────────
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

ok()   { echo -e "${GREEN}[✓]${RESET} $*"; }
info() { echo -e "${CYAN}[*]${RESET} $*"; }
warn() { echo -e "${YELLOW}[!]${RESET} $*"; }
fail() { echo -e "${RED}[✗]${RESET} $*"; }

TOOLS_DIR="/opt/bugbounty-tools"
CONFIG="config.yaml"

echo -e "\n${BOLD}${CYAN}Bug Bounty Framework — Setup${RESET}\n"

# ── 1. مجلد الأدوات ──────────────────────────────────────────────────
info "Creating tools directory: $TOOLS_DIR"
mkdir -p "$TOOLS_DIR"

# ── 2. System packages ───────────────────────────────────────────────
info "Installing system packages..."
apt-get update -qq
apt-get install -y -qq \
    git python3 python3-pip curl nmap ruby ruby-dev \
    libcurl4-openssl-dev libxml2-dev libxslt1-dev build-essential \
    sqlmap
ok "System packages installed"

# ── 3. WPScan ────────────────────────────────────────────────────────
info "Installing wpscan..."
gem install wpscan --quiet 2>/dev/null && ok "wpscan installed" || warn "wpscan failed — skip"

# ── 4. Python tools ──────────────────────────────────────────────────

install_python_tool() {
    local name="$1"
    local repo="$2"
    local dest="$TOOLS_DIR/$name"
    local req="$dest/requirements.txt"

    info "Installing $name..."
    if [ -d "$dest" ]; then
        git -C "$dest" pull -q
    else
        git clone -q "$repo" "$dest"
    fi

    if [ -f "$req" ]; then
        pip3 install -q -r "$req" 2>/dev/null || true
    fi
    ok "$name → $dest"
}

install_python_tool "LinkFinder"    "https://github.com/GerbenJavado/LinkFinder.git"
install_python_tool "SecretFinder"  "https://github.com/m4ll0k/SecretFinder.git"
install_python_tool "corsy"         "https://github.com/s0md3v/Corsy.git"

# ── 5. Go tools ──────────────────────────────────────────────────────
info "Installing Go tools (requires Go 1.21+)..."

if ! command -v go &>/dev/null; then
    fail "Go not found — install Go first: https://go.dev/dl/"
    exit 1
fi

go_tools=(
    "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
    "github.com/tomnomnom/assetfinder@latest"
    "github.com/projectdiscovery/httpx/cmd/httpx@latest"
    "github.com/projectdiscovery/dnsx/cmd/dnsx@latest"
    "github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"
    "github.com/lc/gau/v2/cmd/gau@latest"
    "github.com/tomnomnom/waybackurls@latest"
    "github.com/projectdiscovery/katana/cmd/katana@latest"
    "github.com/hakluke/hakrawler@latest"
    "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
    "github.com/hahwul/dalfox/v2@latest"
    "github.com/ffuf/ffuf/v2@latest"
    "github.com/tomnomnom/anew@latest"
    "github.com/tomnomnom/gf@latest"
    "github.com/tomnomnom/qsreplace@latest"
    "github.com/projectdiscovery/notify/cmd/notify@latest"
)

for tool in "${go_tools[@]}"; do
    name=$(basename "${tool%@*}")
    info "go install $name..."
    go install -v "$tool" 2>/dev/null && ok "$name" || warn "$name failed — skip"
done

# ── 6. GF patterns ───────────────────────────────────────────────────
info "Installing GF patterns..."
mkdir -p ~/.gf
git clone -q https://github.com/1ndianl33t/Gf-Patterns.git /tmp/gf-patterns 2>/dev/null || true
cp /tmp/gf-patterns/*.json ~/.gf/ 2>/dev/null && ok "GF patterns installed" || warn "GF patterns failed"

# ── 7. Nuclei templates ──────────────────────────────────────────────
info "Updating Nuclei templates..."
nuclei -update-templates -silent 2>/dev/null && ok "Nuclei templates updated" || warn "Nuclei templates failed"

# ── 8. Wordlists ─────────────────────────────────────────────────────
SECLISTS="/opt/SecLists"
if [ ! -d "$SECLISTS" ]; then
    info "Cloning SecLists (this may take a while)..."
    git clone -q --depth 1 https://github.com/danielmiessler/SecLists.git "$SECLISTS"
    ok "SecLists → $SECLISTS"
else
    ok "SecLists already present at $SECLISTS"
fi

# ── 9. Update config.yaml ────────────────────────────────────────────
info "Updating config.yaml with correct paths..."

LINKFINDER_PY="$TOOLS_DIR/LinkFinder/linkfinder.py"
SECRETFINDER_PY="$TOOLS_DIR/SecretFinder/SecretFinder.py"
CORSY_PY="$TOOLS_DIR/corsy/corsy.py"
DIR_WORDLIST="$SECLISTS/Discovery/Web-Content/directory-list-2.3-medium.txt"
PARAM_WORDLIST="$SECLISTS/Discovery/Web-Content/burp-parameter-names.txt"

# Use sed to patch the relevant lines in config.yaml
patch_config() {
    local key="$1"
    local val="$2"
    # matches:  key: "anything"  or  key: anything
    sed -i "s|^\([[:space:]]*${key}:\).*|\1 \"${val}\"|" "$CONFIG"
}

patch_config "linkfinder"    "$LINKFINDER_PY"
patch_config "secretfinder"  "$SECRETFINDER_PY"
patch_config "corsy"         "$CORSY_PY"
patch_config "directories"   "$DIR_WORDLIST"
patch_config "parameters"    "$PARAM_WORDLIST"

ok "config.yaml updated"

# ── 10. Build binary ─────────────────────────────────────────────────
info "Building bugbounty binary..."
make build && ok "Binary → ./build/bugbounty"

# ── 11. Verification ─────────────────────────────────────────────────
echo -e "\n${BOLD}── Tool Check ─────────────────────────────────────${RESET}"

check_tool() {
    local name="$1"
    local check_cmd="$2"
    if eval "$check_cmd" &>/dev/null; then
        ok "$name"
    else
        fail "$name — NOT FOUND"
    fi
}

check_tool "subfinder"     "command -v subfinder"
check_tool "httpx"         "command -v httpx"
check_tool "dnsx"          "command -v dnsx"
check_tool "naabu"         "command -v naabu"
check_tool "gau"           "command -v gau"
check_tool "waybackurls"   "command -v waybackurls"
check_tool "katana"        "command -v katana"
check_tool "hakrawler"     "command -v hakrawler"
check_tool "nuclei"        "command -v nuclei"
check_tool "dalfox"        "command -v dalfox"
check_tool "ffuf"          "command -v ffuf"
check_tool "nmap"          "command -v nmap"
check_tool "sqlmap"        "command -v sqlmap"
check_tool "gf"            "command -v gf"
check_tool "anew"          "command -v anew"
check_tool "LinkFinder"    "test -f $LINKFINDER_PY"
check_tool "SecretFinder"  "test -f $SECRETFINDER_PY"
check_tool "corsy"         "test -f $CORSY_PY"
check_tool "SecLists"      "test -d $SECLISTS"

echo -e "\n${GREEN}${BOLD}Setup complete!${RESET}"
echo -e "Run: ${CYAN}./build/bugbounty -target example.com -scope scope.txt${RESET}\n"
