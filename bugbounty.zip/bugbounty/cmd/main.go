package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/bugbounty/internal/config"
	"github.com/bugbounty/internal/logger"
	"github.com/bugbounty/internal/notify"
	"github.com/bugbounty/internal/output"
	"github.com/bugbounty/internal/phases"
	"github.com/bugbounty/internal/scope"
)

// ─────────────────────────────────────────
//  CLI flags
// ─────────────────────────────────────────

type flags struct {
	target     string
	configPath string
	scopePath  string
	phase      string
	outputDir  string
	continuous bool
	interval   time.Duration
	verbose    bool
}

func parseFlags() flags {
	f := flags{}
	flag.StringVar(&f.target, "target", "", "Target domain  (required) — e.g. example.com")
	flag.StringVar(&f.configPath, "config", "config.yaml", "Path to config.yaml")
	flag.StringVar(&f.scopePath, "scope", "scope.txt", "Path to scope.txt")
	flag.StringVar(&f.phase, "phase", "all",
		"Phase to run: all | recon | discovery | scanning | vulns | validation")
	flag.StringVar(&f.outputDir, "output", "", "Override output directory from config")
	flag.BoolVar(&f.continuous, "continuous", false, "Run in continuous monitoring mode")
	flag.DurationVar(&f.interval, "interval", 24*time.Hour, "Interval for continuous mode")
	flag.BoolVar(&f.verbose, "verbose", false, "Enable verbose / debug logging")
	flag.Parse()
	return f
}

// ─────────────────────────────────────────
//  main
// ─────────────────────────────────────────

func main() {
	f := parseFlags()

	logger.Banner()
	logger.SetVerbose(f.verbose)

	// ── validate required args ────────────────────────────────────
	if f.target == "" {
		fmt.Fprintln(os.Stderr, "[!] -target is required")
		flag.Usage()
		os.Exit(1)
	}

	// ── load config ───────────────────────────────────────────────
	cfg, err := config.Load(f.configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[!] Config: %v\n", err)
		os.Exit(1)
	}
	if f.verbose {
		cfg.Verbose = true
	}
	if f.outputDir != "" {
		cfg.OutputDir = f.outputDir
	}

	// ── load scope ────────────────────────────────────────────────
	sv, err := scope.LoadFromFile(f.scopePath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[!] Scope: %v\n", err)
		os.Exit(1)
	}

	// ── scope check ───────────────────────────────────────────────
	if !sv.InScope(f.target) {
		fmt.Fprintf(os.Stderr, "[!] Target %q is NOT in scope — aborting\n", f.target)
		os.Exit(1)
	}

	// ── build session output dir ──────────────────────────────────
	sessionDir := fmt.Sprintf("%s/%s_%s",
		cfg.OutputDir, f.target, time.Now().Format("20060102_150405"))

	w, err := output.New(sessionDir)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[!] Output: %v\n", err)
		os.Exit(1)
	}

	// ── notifier ──────────────────────────────────────────────────
	n := notify.New(cfg.APIs.TelegramToken, cfg.APIs.TelegramChat, cfg.APIs.DiscordWebhook)

	// ── context + graceful shutdown ───────────────────────────────
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		sig := <-sigCh
		logger.Warning("MAIN", fmt.Sprintf("Received %v — shutting down...", sig))
		cancel()
		// give goroutines 5 s to clean up, then hard exit
		time.Sleep(5 * time.Second)
		os.Exit(0)
	}()

	// ── run ───────────────────────────────────────────────────────
	if f.continuous {
		runContinuous(ctx, f, cfg, sv, w, n)
	} else {
		if err := runOnce(ctx, f, cfg, sv, w, n); err != nil {
			logger.Error("MAIN", err.Error())
			os.Exit(1)
		}
	}
}

// ─────────────────────────────────────────
//  Single run
// ─────────────────────────────────────────

func runOnce(
	ctx context.Context,
	f flags,
	cfg *config.Config,
	sv *scope.Validator,
	w *output.Writer,
	n *notify.Notifier,
) error {
	start := time.Now()
	logger.Info("MAIN", fmt.Sprintf("Target: %s | Phase: %s", f.target, f.phase))

	var (
		reconResult    *phases.ReconResult
		discoveryResult *phases.DiscoveryResult
		scanResult     *phases.ScanResult
		vulnResult     *phases.VulnResult
	)

	// ── Phase 1: Recon ────────────────────────────────────────────
	if shouldRun(f.phase, "recon") && cfg.Phases.Recon {
		r, err := phases.RunRecon(ctx, f.target, cfg, sv, w)
		if err != nil {
			return fmt.Errorf("recon: %w", err)
		}
		reconResult = r
		n.PhaseComplete("RECON", len(r.Subdomains))
	}
	if reconResult == nil {
		reconResult = &phases.ReconResult{}
	}

	if len(reconResult.LiveHosts) == 0 && f.phase == "all" {
		logger.Warning("MAIN", "No live hosts found — subsequent phases skipped")
		return nil
	}

	// ── Phase 2: Discovery ────────────────────────────────────────
	if shouldRun(f.phase, "discovery") && cfg.Phases.Discovery {
		d, err := phases.RunDiscovery(ctx, cfg, reconResult, w)
		if err != nil {
			return fmt.Errorf("discovery: %w", err)
		}
		discoveryResult = d
		n.PhaseComplete("DISCOVERY", len(d.AllURLs))
	}
	if discoveryResult == nil {
		discoveryResult = &phases.DiscoveryResult{
			ParamFiles: make(map[string]string),
			TechStacks: make(map[string]*phases.TechStack),
		}
	}

	// ── Phase 3: Scanning ─────────────────────────────────────────
	if shouldRun(f.phase, "scanning") && cfg.Phases.Scanning {
		s, err := phases.RunScanning(ctx, cfg, reconResult, discoveryResult, w)
		if err != nil {
			return fmt.Errorf("scanning: %w", err)
		}
		scanResult = s
		total := 0
		for _, ports := range s.OpenPorts {
			total += len(ports)
		}
		n.PhaseComplete("SCANNING", total)
	}
	if scanResult == nil {
		scanResult = &phases.ScanResult{OpenPorts: make(map[string][]string)}
	}

	// ── Phase 4: Vulns ────────────────────────────────────────────
	if shouldRun(f.phase, "vulns") && cfg.Phases.Vulns {
		v, err := phases.RunVulns(ctx, cfg, reconResult, discoveryResult, w, n)
		if err != nil {
			return fmt.Errorf("vulns: %w", err)
		}
		vulnResult = v
		n.PhaseComplete("VULNS", len(v.Findings))
	}
	if vulnResult == nil {
		vulnResult = &phases.VulnResult{}
	}

	// ── Phase 5: Validation ───────────────────────────────────────
	if shouldRun(f.phase, "validation") && cfg.Phases.Validation {
		vr, err := phases.RunValidation(ctx, cfg, vulnResult, w)
		if err != nil {
			return fmt.Errorf("validation: %w", err)
		}
		n.PhaseComplete("VALIDATION", len(vr.ValidatedFindings))
	}

	// ── Summary ───────────────────────────────────────────────────
	elapsed  := time.Since(start).Round(time.Second)
	stats    := w.Stats()
	findings := w.Findings()

	printSummary(f.target, elapsed, stats)
	n.ScanComplete(f.target, stats, findings)

	return nil
}

// ─────────────────────────────────────────
//  Continuous mode
// ─────────────────────────────────────────

func runContinuous(
	ctx context.Context,
	f flags,
	cfg *config.Config,
	sv *scope.Validator,
	w *output.Writer,
	n *notify.Notifier,
) {
	logger.Info("MAIN", fmt.Sprintf("Continuous mode — interval: %v", f.interval))

	for {
		if err := runOnce(ctx, f, cfg, sv, w, n); err != nil {
			logger.Error("MAIN", fmt.Sprintf("Run failed: %v", err))
		}

		select {
		case <-ctx.Done():
			logger.Info("MAIN", "Continuous mode stopped")
			return
		case <-time.After(f.interval):
			logger.Info("MAIN", "Starting next scan cycle...")
		}
	}
}

// ─────────────────────────────────────────
//  Helpers
// ─────────────────────────────────────────

// shouldRun returns true when the selected phase matches or "all" is chosen.
func shouldRun(selected, phase string) bool {
	return strings.EqualFold(selected, "all") || strings.EqualFold(selected, phase)
}

// printSummary writes a coloured summary table to stderr.
func printSummary(target string, elapsed time.Duration, stats output.Stats) {
	border := strings.Repeat("─", 52)
	fmt.Fprintf(os.Stderr, "\n\033[1m%s\033[0m\n", border)
	fmt.Fprintf(os.Stderr, "  \033[1mScan complete\033[0m — %s  (%v)\n", target, elapsed)
	fmt.Fprintf(os.Stderr, "%s\n", border)
	fmt.Fprintf(os.Stderr, "  \033[31mCritical : %d\033[0m\n", stats.Critical)
	fmt.Fprintf(os.Stderr, "  \033[33mHigh     : %d\033[0m\n", stats.High)
	fmt.Fprintf(os.Stderr, "  \033[33mMedium   : %d\033[0m\n", stats.Medium)
	fmt.Fprintf(os.Stderr, "  \033[32mLow      : %d\033[0m\n", stats.Low)
	fmt.Fprintf(os.Stderr, "  \033[36mTotal    : %d\033[0m\n", stats.Total)
	fmt.Fprintf(os.Stderr, "%s\n\n", border)
}
