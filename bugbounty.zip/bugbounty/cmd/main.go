package main

import (
	"bufio"
	"context"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/bugbounty/internal/config"
	"github.com/bugbounty/internal/logger"
	"github.com/bugbounty/internal/notify"
	"github.com/bugbounty/internal/output"
	"github.com/bugbounty/internal/phases"
	"github.com/bugbounty/internal/scope"
)

// ─────────────────────────────────────────
//  CLI flags
// ─────────────────────────────────────────

type flags struct {
	target      string        // single target
	targetsFile string        // file with multiple targets (one per line)
	configPath  string
	scopePath   string
	phase       string
	outputDir   string
	continuous  bool
	interval    time.Duration
	verbose     bool
}

func parseFlags() flags {
	f := flags{}
	flag.StringVar(&f.target, "target", "",
		"Single target domain — e.g. example.com")
	flag.StringVar(&f.targetsFile, "targets", "",
		"File with multiple targets, one per line — e.g. targets.txt")
	flag.StringVar(&f.configPath, "config", "config.yaml",
		"Path to config.yaml")
	flag.StringVar(&f.scopePath, "scope", "scope.txt",
		"Path to scope.txt")
	flag.StringVar(&f.phase, "phase", "all",
		"Phase to run: all | recon | discovery | scanning | vulns | validation")
	flag.StringVar(&f.outputDir, "output", "",
		"Override output directory from config")
	flag.BoolVar(&f.continuous, "continuous", false,
		"Re-run all targets on a schedule")
	flag.DurationVar(&f.interval, "interval", 24*time.Hour,
		"Interval between continuous runs")
	flag.BoolVar(&f.verbose, "verbose", false,
		"Enable verbose / debug logging")
	flag.Parse()
	return f
}

// ─────────────────────────────────────────
//  main
// ─────────────────────────────────────────

func main() {
	f := parseFlags()

	logger.Banner()
	logger.SetVerbose(f.verbose)

	// ── must provide at least one target ─────────────────────────
	if f.target == "" && f.targetsFile == "" {
		fmt.Fprintln(os.Stderr, "[!] Provide -target example.com  OR  -targets targets.txt")
		flag.Usage()
		os.Exit(1)
	}

	// ── load config ───────────────────────────────────────────────
	cfg, err := config.Load(f.configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[!] Config: %v\n", err)
		os.Exit(1)
	}
	if f.verbose {
		cfg.Verbose = true
	}
	if f.outputDir != "" {
		cfg.OutputDir = f.outputDir
	}

	// ── load scope ────────────────────────────────────────────────
	sv, err := scope.LoadFromFile(f.scopePath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[!] Scope: %v\n", err)
		os.Exit(1)
	}

	// ── build target list ─────────────────────────────────────────
	targets, err := resolveTargets(f)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[!] Targets: %v\n", err)
		os.Exit(1)
	}
	if len(targets) == 0 {
		fmt.Fprintln(os.Stderr, "[!] No targets found")
		os.Exit(1)
	}

	// ── notifier (shared across all targets) ──────────────────────
	n := notify.New(cfg.APIs.TelegramToken, cfg.APIs.TelegramChat, cfg.APIs.DiscordWebhook)

	// ── context + graceful shutdown ───────────────────────────────
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		sig := <-sigCh
		logger.Warning("MAIN", fmt.Sprintf("Received %v — shutting down gracefully...", sig))
		cancel()
		time.Sleep(5 * time.Second)
		os.Exit(0)
	}()

	// ── announce ──────────────────────────────────────────────────
	logger.Info("MAIN", fmt.Sprintf(
		"%d target(s) queued: %s", len(targets), strings.Join(targets, ", ")))

	// ── run ───────────────────────────────────────────────────────
	if f.continuous {
		runContinuous(ctx, targets, f, cfg, sv, n)
	} else {
		runAllTargets(ctx, targets, f, cfg, sv, n)
	}
}

// ─────────────────────────────────────────
//  Multi-target runner
// ─────────────────────────────────────────

// targetResult holds the outcome for a single target.
type targetResult struct {
	target  string
	stats   output.Stats
	elapsed time.Duration
	err     error
}

// runAllTargets scans every target sequentially and prints a combined summary.
// Targets are run one at a time — parallel scanning risks bans and noise.
func runAllTargets(
	ctx context.Context,
	targets []string,
	f flags,
	cfg *config.Config,
	sv *scope.Validator,
	n *notify.Notifier,
) {
	sessionTS := time.Now().Format("20060102_150405")
	totalStart := time.Now()
	results := make([]targetResult, 0, len(targets))

	for i, target := range targets {
		// ── check context before every target ────────────────────
		select {
		case <-ctx.Done():
			logger.Warning("MAIN", "Interrupted — stopping target queue")
			return
		default:
		}

		border := strings.Repeat("═", 56)
		logger.Info("MAIN", fmt.Sprintf(
			"\n%s\n  [%d/%d] Starting: %s\n%s",
			border, i+1, len(targets), target, border))

		// ── scope check (per target) ──────────────────────────────
		if !sv.InScope(target) {
			logger.Warning("MAIN", fmt.Sprintf(
				"Target %q is NOT in scope — skipping", target))
			results = append(results, targetResult{
				target: target,
				err:    fmt.Errorf("out of scope"),
			})
			continue
		}

		// ── dedicated output dir per target ──────────────────────
		sessionDir := fmt.Sprintf("%s/%s_%s", cfg.OutputDir, target, sessionTS)
		w, err := output.New(sessionDir)
		if err != nil {
			logger.Error("MAIN", fmt.Sprintf("Output dir for %s: %v", target, err))
			results = append(results, targetResult{target: target, err: err})
			continue
		}

		// ── scan ──────────────────────────────────────────────────
		start := time.Now()
		scanErr := runOnce(ctx, target, f, cfg, sv, w, n)
		elapsed := time.Since(start).Round(time.Second)

		stats := w.Stats()
		results = append(results, targetResult{
			target:  target,
			stats:   stats,
			elapsed: elapsed,
			err:     scanErr,
		})

		if scanErr != nil {
			logger.Error("MAIN", fmt.Sprintf("%s failed: %v", target, scanErr))
		}

		// ── cooldown between targets to avoid rate-limit bans ─────
		if i < len(targets)-1 {
			cooldown := 30 * time.Second
			logger.Info("MAIN", fmt.Sprintf(
				"Cooldown %v before next target...", cooldown))
			select {
			case <-time.After(cooldown):
			case <-ctx.Done():
				return
			}
		}
	}

	// ── combined summary ──────────────────────────────────────────
	printCombinedSummary(results, time.Since(totalStart))
	sendCombinedNotification(n, results)
}

// ─────────────────────────────────────────
//  Single target scan
// ─────────────────────────────────────────

func runOnce(
	ctx context.Context,
	target string,
	f flags,
	cfg *config.Config,
	sv *scope.Validator,
	w *output.Writer,
	n *notify.Notifier,
) error {
	start := time.Now()
	logger.Info("MAIN", fmt.Sprintf("Target: %s | Phase: %s", target, f.phase))

	var (
		reconResult     *phases.ReconResult
		discoveryResult *phases.DiscoveryResult
		scanResult      *phases.ScanResult
		vulnResult      *phases.VulnResult
	)

	// ── Phase 1 ───────────────────────────────────────────────────
	if shouldRun(f.phase, "recon") && cfg.Phases.Recon {
		r, err := phases.RunRecon(ctx, target, cfg, sv, w)
		if err != nil {
			return fmt.Errorf("recon: %w", err)
		}
		reconResult = r
		n.PhaseComplete("RECON", len(r.Subdomains))
	}
	if reconResult == nil {
		reconResult = &phases.ReconResult{}
	}
	if len(reconResult.LiveHosts) == 0 && f.phase == "all" {
		logger.Warning("MAIN", fmt.Sprintf(
			"%s — no live hosts found, skipping remaining phases", target))
		return nil
	}

	// ── Phase 2 ───────────────────────────────────────────────────
	if shouldRun(f.phase, "discovery") && cfg.Phases.Discovery {
		d, err := phases.RunDiscovery(ctx, cfg, reconResult, w)
		if err != nil {
			return fmt.Errorf("discovery: %w", err)
		}
		discoveryResult = d
		n.PhaseComplete("DISCOVERY", len(d.AllURLs))
	}
	if discoveryResult == nil {
		discoveryResult = &phases.DiscoveryResult{
			ParamFiles: make(map[string]string),
			TechStacks: make(map[string]*phases.TechStack),
		}
	}

	// ── Phase 3 ───────────────────────────────────────────────────
	if shouldRun(f.phase, "scanning") && cfg.Phases.Scanning {
		s, err := phases.RunScanning(ctx, cfg, reconResult, discoveryResult, w)
		if err != nil {
			return fmt.Errorf("scanning: %w", err)
		}
		scanResult = s
		total := 0
		for _, ports := range s.OpenPorts {
			total += len(ports)
		}
		n.PhaseComplete("SCANNING", total)
	}
	if scanResult == nil {
		scanResult = &phases.ScanResult{OpenPorts: make(map[string][]string)}
	}

	// ── Phase 4 ───────────────────────────────────────────────────
	if shouldRun(f.phase, "vulns") && cfg.Phases.Vulns {
		v, err := phases.RunVulns(ctx, cfg, reconResult, discoveryResult, w, n)
		if err != nil {
			return fmt.Errorf("vulns: %w", err)
		}
		vulnResult = v
		n.PhaseComplete("VULNS", len(v.Findings))
	}
	if vulnResult == nil {
		vulnResult = &phases.VulnResult{}
	}

	// ── Phase 5 ───────────────────────────────────────────────────
	if shouldRun(f.phase, "validation") && cfg.Phases.Validation {
		vr, err := phases.RunValidation(ctx, cfg, vulnResult, w)
		if err != nil {
			return fmt.Errorf("validation: %w", err)
		}
		n.PhaseComplete("VALIDATION", len(vr.ValidatedFindings))
	}

	// ── per-target summary ────────────────────────────────────────
	elapsed  := time.Since(start).Round(time.Second)
	stats    := w.Stats()
	findings := w.Findings()

	printSummary(target, elapsed, stats)
	n.ScanComplete(target, stats, findings)

	return nil
}

// ─────────────────────────────────────────
//  Continuous mode
// ─────────────────────────────────────────

func runContinuous(
	ctx context.Context,
	targets []string,
	f flags,
	cfg *config.Config,
	sv *scope.Validator,
	n *notify.Notifier,
) {
	logger.Info("MAIN", fmt.Sprintf(
		"Continuous mode — %d target(s), interval: %v", len(targets), f.interval))

	for {
		runAllTargets(ctx, targets, f, cfg, sv, n)

		select {
		case <-ctx.Done():
			logger.Info("MAIN", "Continuous mode stopped")
			return
		case <-time.After(f.interval):
			logger.Info("MAIN", "Starting next scan cycle...")
		}
	}
}

// ─────────────────────────────────────────
//  Target resolution
// ─────────────────────────────────────────

// resolveTargets builds the final deduplicated target list from CLI flags.
func resolveTargets(f flags) ([]string, error) {
	seen := make(map[string]struct{})
	var targets []string

	add := func(t string) {
		t = strings.ToLower(strings.TrimSpace(t))
		if t == "" || strings.HasPrefix(t, "#") {
			return
		}
		if _, dup := seen[t]; !dup {
			seen[t] = struct{}{}
			targets = append(targets, t)
		}
	}

	// -target single domain
	if f.target != "" {
		add(f.target)
	}

	// -targets file
	if f.targetsFile != "" {
		file, err := os.Open(f.targetsFile)
		if err != nil {
			return nil, fmt.Errorf("cannot open targets file %q: %w", f.targetsFile, err)
		}
		defer file.Close()

		sc := bufio.NewScanner(file)
		lineNum := 0
		for sc.Scan() {
			lineNum++
			add(sc.Text())
		}
		if err := sc.Err(); err != nil {
			return nil, fmt.Errorf("reading targets file: %w", err)
		}
		if len(targets) == 0 {
			return nil, fmt.Errorf("targets file %q has no valid entries", f.targetsFile)
		}
	}

	return targets, nil
}

// ─────────────────────────────────────────
//  Summaries
// ─────────────────────────────────────────

// printSummary prints a per-target coloured table.
func printSummary(target string, elapsed time.Duration, stats output.Stats) {
	b := strings.Repeat("─", 54)
	fmt.Fprintf(os.Stderr, "\n\033[1m%s\033[0m\n", b)
	fmt.Fprintf(os.Stderr, "  \033[1mDone:\033[0m %s  (%v)\n", target, elapsed)
	fmt.Fprintf(os.Stderr, "%s\n", b)
	fmt.Fprintf(os.Stderr, "  \033[31mCritical : %d\033[0m\n", stats.Critical)
	fmt.Fprintf(os.Stderr, "  \033[33mHigh     : %d\033[0m\n", stats.High)
	fmt.Fprintf(os.Stderr, "  \033[33mMedium   : %d\033[0m\n", stats.Medium)
	fmt.Fprintf(os.Stderr, "  \033[32mLow      : %d\033[0m\n", stats.Low)
	fmt.Fprintf(os.Stderr, "  \033[36mTotal    : %d\033[0m\n", stats.Total)
	fmt.Fprintf(os.Stderr, "%s\n\n", b)
}

// printCombinedSummary prints a final table covering all targets.
func printCombinedSummary(results []targetResult, total time.Duration) {
	b := strings.Repeat("═", 60)
	fmt.Fprintf(os.Stderr, "\n\033[1;36m%s\033[0m\n", b)
	fmt.Fprintf(os.Stderr, "  \033[1;36mALL TARGETS COMPLETE\033[0m  (total: %v)\n", total.Round(time.Second))
	fmt.Fprintf(os.Stderr, "\033[1;36m%s\033[0m\n\n", b)

	var grandTotal output.Stats
	for _, r := range results {
		status := "✅"
		if r.err != nil {
			status = "❌"
		}
		fmt.Fprintf(os.Stderr,
			"  %s \033[1m%-30s\033[0m  C:\033[31m%d\033[0m  H:\033[33m%d\033[0m  M:\033[33m%d\033[0m  L:\033[32m%d\033[0m  (%v)\n",
			status, r.target,
			r.stats.Critical, r.stats.High, r.stats.Medium, r.stats.Low,
			r.elapsed,
		)
		grandTotal.Critical += r.stats.Critical
		grandTotal.High     += r.stats.High
		grandTotal.Medium   += r.stats.Medium
		grandTotal.Low      += r.stats.Low
		grandTotal.Total    += r.stats.Total
	}

	fmt.Fprintf(os.Stderr, "\n  \033[1mGrand Total:\033[0m")
	fmt.Fprintf(os.Stderr, "  \033[31mCritical:%d\033[0m", grandTotal.Critical)
	fmt.Fprintf(os.Stderr, "  \033[33mHigh:%d\033[0m", grandTotal.High)
	fmt.Fprintf(os.Stderr, "  \033[33mMedium:%d\033[0m", grandTotal.Medium)
	fmt.Fprintf(os.Stderr, "  \033[32mLow:%d\033[0m", grandTotal.Low)
	fmt.Fprintf(os.Stderr, "  \033[36mTotal:%d\033[0m\n\n", grandTotal.Total)
}

// sendCombinedNotification sends the combined summary to Telegram/Discord.
func sendCombinedNotification(n *notify.Notifier, results []targetResult) {
	var lines []string
	var combined output.Stats

	for _, r := range results {
		status := "✅"
		if r.err != nil {
			status = fmt.Sprintf("❌ (%v)", r.err)
		}
		lines = append(lines, fmt.Sprintf(
			"%s *%s*\n    🔴%d 🟠%d 🟡%d 🟢%d  (%v)",
			status, r.target,
			r.stats.Critical, r.stats.High, r.stats.Medium, r.stats.Low,
			r.elapsed,
		))
		combined.Critical += r.stats.Critical
		combined.High     += r.stats.High
		combined.Medium   += r.stats.Medium
		combined.Low      += r.stats.Low
		combined.Total    += r.stats.Total
	}

	msg := fmt.Sprintf(
		"🏁 *All Targets Complete*\n\n%s\n\n"+
			"📊 *Grand Total*\n"+
			"🔴 Critical : `%d`\n"+
			"🟠 High     : `%d`\n"+
			"🟡 Medium   : `%d`\n"+
			"🟢 Low      : `%d`\n"+
			"📦 Total    : `%d`",
		strings.Join(lines, "\n\n"),
		combined.Critical, combined.High,
		combined.Medium, combined.Low, combined.Total,
	)

	n.SendRaw(msg, 0x0099FF)
}

// ─────────────────────────────────────────
//  Helpers
// ─────────────────────────────────────────

func shouldRun(selected, phase string) bool {
	return strings.EqualFold(selected, "all") || strings.EqualFold(selected, phase)
}
