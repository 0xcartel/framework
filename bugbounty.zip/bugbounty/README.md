# Bug Bounty Automation Framework

Go + Python automation framework for structured, parallel bug bounty hunting.

---

## Architecture

```
bugbounty/
├── cmd/main.go                     # Entry point, CLI, orchestration
├── internal/
│   ├── config/config.go            # YAML config loader + validation
│   ├── scope/validator.go          # In-scope / out-of-scope enforcement
│   ├── logger/logger.go            # Coloured terminal logging
│   ├── runner/runner.go            # WorkerPool, RateLimiter, tool executor
│   ├── output/writer.go            # File I/O, dedup, findings store
│   ├── notify/notify.go            # Telegram + Discord alerts
│   └── phases/
│       ├── recon.go                # Phase 1 — Subdomain discovery
│       ├── discovery.go            # Phase 2 — URL discovery + fingerprinting
│       ├── scanning.go             # Phase 3 — Port + directory scanning
│       ├── vulns.go                # Phase 4 — Vulnerability testing
│       └── validation.go          # Phase 5 — Dedup, FP filter, PoC gen
├── reporter/report.py              # HTML report generator (Python)
├── config.yaml                     # User settings
├── scope.txt                       # In-scope targets
└── Makefile                        # Build + run shortcuts
```

---

## Workflow

```
scope.txt + config.yaml
        │
        ▼
  Phase 0: Scope Validation
        │
        ▼
  Phase 1: RECON (parallel)
  subfinder · amass · assetfinder · crt.sh · chaos
  dnsx · httpx
        │
        ▼
  Phase 2: DISCOVERY (parallel)
  gau · waybackurls · katana · hakrawler
  gf (param patterns) · linkfinder · tech fingerprint
        │
        ▼
  Phase 3: SMART SCANNING
  naabu → nmap (targeted) · ffuf · wpscan (if WP detected) · API discovery
        │
        ▼
  Phase 4: VULN TESTING (parallel)
  nuclei (critical+high) · dalfox · corsy
  secretfinder · sqlmap · open-redirect
  nuclei (medium)
        │
        ▼
  Phase 5: VALIDATION
  dedup · false-positive filter · CVSS scoring · PoC generation
        │
        ▼
  Phase 6: REPORTING
  findings.json · per-severity .txt files
  HTML report (Python) · Telegram / Discord alerts
```

---

## Quick Start

### 1. Install Go tools

```bash
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/owasp-amass/amass/v4/...@master
go install -v github.com/tomnomnom/assetfinder@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install -v github.com/lc/gau/v2/cmd/gau@latest
go install -v github.com/tomnomnom/waybackurls@latest
go install -v github.com/projectdiscovery/katana/cmd/katana@latest
go install -v github.com/hakluke/hakrawler@latest
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go install -v github.com/hahwul/dalfox/v2@latest
go install -v github.com/tomnomnom/anew@latest
go install -v github.com/tomnomnom/gf@latest
go install -v github.com/projectdiscovery/notify/cmd/notify@latest

# Python tools
pip install corsy secretfinder
```

### 2. Build

```bash
make build
# Binary → ./build/bugbounty
```

### 3. Configure

Edit **config.yaml** — add your API keys (Shodan, Chaos, Telegram, Discord).

### 4. Define scope

```bash
# scope.txt
example.com
*.example.com
api.example.com
```

### 5. Run

```bash
# Full scan
make run TARGET=example.com

# Single phase
make run-recon     TARGET=example.com
make run-discovery TARGET=example.com
make run-vulns     TARGET=example.com

# Continuous monitoring (every 24h)
make run-continuous TARGET=example.com

# Generate HTML report
make report TARGET=example.com FINDINGS=./output/example.com_*/reports/findings.json
```

### 6. Direct binary usage

```bash
./build/bugbounty -target example.com -phase all -verbose

# Options
#   -target      Target domain (required)
#   -config      Path to config.yaml       (default: config.yaml)
#   -scope       Path to scope.txt         (default: scope.txt)
#   -phase       all|recon|discovery|scanning|vulns|validation
#   -output      Override output directory
#   -continuous  Run on a schedule
#   -interval    Schedule interval         (default: 24h)
#   -verbose     Debug output
```

---

## Output Structure

```
output/
└── example.com_20240101_120000/
    ├── recon/
    │   ├── subdomains.txt
    │   ├── live_hosts.txt
    │   └── ips.txt
    ├── discovery/
    │   ├── all_urls.txt
    │   ├── js_files.txt
    │   ├── js_endpoints.txt
    │   └── params_{xss,sqli,ssrf,...}.txt
    ├── scanning/
    │   ├── open_ports.txt
    │   ├── directories.txt
    │   └── nmap_*.txt
    ├── vulns/
    │   ├── nuclei_critical_high.json
    │   ├── dalfox_xss.txt
    │   └── cors_findings.txt
    ├── validation/
    │   ├── vulns_critical.txt
    │   ├── vulns_high.txt
    │   └── vulns_medium.txt
    └── reports/
        ├── findings.json       ← structured data for all findings
        └── report.html         ← generated by reporter/report.py
```

---

## Notifications

Set in **config.yaml**:

```yaml
apis:
  telegram_token: "BOT_TOKEN"
  telegram_chat:  "CHAT_ID"
  discord_webhook: "https://discord.com/api/webhooks/..."
```

Alerts fire immediately on **Critical** and **High** findings.
Phase-complete summaries are sent after each phase.

---

## Legal

**Only run against targets you have explicit written permission to test.**
Always read the Bug Bounty program's rules before scanning.
This tool is for authorised security research only.
