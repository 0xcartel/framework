package runner

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"os/exec"
	"strings"
	"sync"
	"time"

	"github.com/bugbounty/internal/logger"
)

// ─────────────────────────────────────────
//  Job / Result
// ─────────────────────────────────────────

// Job describes one unit of external-tool work.
type Job struct {
	Name    string        // human label used in logs
	Cmd     string        // binary to execute
	Args    []string      // arguments
	Timeout time.Duration // 0 → 5 min default
	Retries int           // 0 → 1 attempt (no retry)
}

// Result is what a completed Job returns.
type Result struct {
	Tool    string
	Lines   []string
	Error   error
	Elapsed time.Duration
}

// ─────────────────────────────────────────
//  WorkerPool
// ─────────────────────────────────────────

// WorkerPool runs Jobs concurrently with a fixed number of goroutines.
type WorkerPool struct {
	workers int
	jobs    chan Job
	results chan Result
	wg      sync.WaitGroup
}

// NewWorkerPool returns a pool ready to Start.
func NewWorkerPool(workers int) *WorkerPool {
	if workers <= 0 {
		workers = 10
	}
	return &WorkerPool{
		workers: workers,
		jobs:    make(chan Job, workers*4),
		results: make(chan Result, workers*4),
	}
}

// Start launches worker goroutines. Call Close+Wait when done submitting.
func (p *WorkerPool) Start(ctx context.Context) {
	for i := 0; i < p.workers; i++ {
		p.wg.Add(1)
		go func() {
			defer p.wg.Done()
			for {
				select {
				case job, ok := <-p.jobs:
					if !ok {
						return
					}
					r := execWithRetry(ctx, job)
					select {
					case p.results <- r:
					case <-ctx.Done():
						return
					}
				case <-ctx.Done():
					return
				}
			}
		}()
	}
}

// Submit enqueues a job (blocks if the queue is full).
func (p *WorkerPool) Submit(job Job) { p.jobs <- job }

// Close signals that no more jobs will be submitted.
func (p *WorkerPool) Close() { close(p.jobs) }

// Wait waits for all workers to finish, then closes the results channel.
func (p *WorkerPool) Wait() {
	p.wg.Wait()
	close(p.results)
}

// Results returns the channel from which callers read completed Results.
func (p *WorkerPool) Results() <-chan Result { return p.results }

// ─────────────────────────────────────────
//  Execution
// ─────────────────────────────────────────

// execWithRetry runs a Job, retrying on failure with exponential back-off.
func execWithRetry(ctx context.Context, job Job) Result {
	attempts := job.Retries
	if attempts <= 0 {
		attempts = 1
	}

	var last Result
	for i := 0; i < attempts; i++ {
		if i > 0 {
			wait := time.Duration(i) * 2 * time.Second
			logger.Debug(job.Name, fmt.Sprintf("retry %d/%d after %v", i, attempts, wait))
			select {
			case <-time.After(wait):
			case <-ctx.Done():
				last.Error = ctx.Err()
				return last
			}
		}
		last = execTool(ctx, job)
		if last.Error == nil {
			return last
		}
	}
	return last
}

// execTool forks one external command, streams its stdout, and returns all lines.
func execTool(ctx context.Context, job Job) Result {
	timeout := job.Timeout
	if timeout <= 0 {
		timeout = 5 * time.Minute
	}

	tCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	start := time.Now()
	cmd := exec.CommandContext(tCtx, job.Cmd, job.Args...)

	var stderr bytes.Buffer
	cmd.Stderr = &stderr

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return Result{Tool: job.Name, Error: fmt.Errorf("stdout pipe: %w", err)}
	}

	if err := cmd.Start(); err != nil {
		return Result{
			Tool:  job.Name,
			Error: fmt.Errorf("start %q: %w", job.Cmd, err),
		}
	}

	var lines []string
	scanner := bufio.NewScanner(stdout)
	// increase buffer for very long lines (e.g. nuclei JSON)
	buf := make([]byte, 0, 256*1024)
	scanner.Buffer(buf, 1024*1024)

	for scanner.Scan() {
		if line := strings.TrimSpace(scanner.Text()); line != "" {
			lines = append(lines, line)
		}
	}

	if waitErr := cmd.Wait(); waitErr != nil {
		if tCtx.Err() == context.DeadlineExceeded {
			return Result{
				Tool:    job.Name,
				Lines:   lines, // partial output is still useful
				Error:   fmt.Errorf("timeout after %v", timeout),
				Elapsed: time.Since(start),
			}
		}
		// Many security tools exit non-zero even when they found results;
		// return lines AND the error so callers can decide.
		return Result{
			Tool:    job.Name,
			Lines:   lines,
			Error:   fmt.Errorf("exit: %w (stderr: %s)", waitErr, stderr.String()),
			Elapsed: time.Since(start),
		}
	}

	return Result{Tool: job.Name, Lines: lines, Elapsed: time.Since(start)}
}

// ─────────────────────────────────────────
//  Convenience wrapper
// ─────────────────────────────────────────

// Run executes one tool synchronously and logs the outcome.
// It always returns whatever lines were captured, even if err != nil.
func Run(ctx context.Context, phase, tool string, args []string, timeout time.Duration) ([]string, error) {
	job := Job{Name: tool, Cmd: tool, Args: args, Timeout: timeout, Retries: 2}
	r := execWithRetry(ctx, job)

	if r.Error != nil {
		logger.Warning(phase, fmt.Sprintf("%s failed: %v", tool, r.Error))
	} else {
		logger.Success(phase, fmt.Sprintf("%s → %d results in %v",
			tool, len(r.Lines), r.Elapsed.Round(time.Second)))
	}
	return r.Lines, r.Error
}

// ─────────────────────────────────────────
//  Deduplication helpers
// ─────────────────────────────────────────

// Deduplicate returns a new slice with duplicate strings removed,
// preserving the first occurrence order.
func Deduplicate(lines []string) []string {
	seen := make(map[string]struct{}, len(lines))
	out := make([]string, 0, len(lines))
	for _, l := range lines {
		if l == "" {
			continue
		}
		if _, dup := seen[l]; !dup {
			seen[l] = struct{}{}
			out = append(out, l)
		}
	}
	return out
}

// Merge concatenates multiple slices then deduplicates.
func Merge(slices ...[]string) []string {
	total := 0
	for _, s := range slices {
		total += len(s)
	}
	all := make([]string, 0, total)
	for _, s := range slices {
		all = append(all, s...)
	}
	return Deduplicate(all)
}

// ─────────────────────────────────────────
//  Rate limiter (token bucket)
// ─────────────────────────────────────────

// RateLimiter emits tokens at a fixed rate so callers can self-throttle.
type RateLimiter struct {
	tokens chan struct{}
	stop   chan struct{}
	once   sync.Once
}

// NewRateLimiter creates a limiter that allows rps tokens per second.
// rps ≤ 0 disables limiting (Wait returns immediately).
func NewRateLimiter(rps int) *RateLimiter {
	rl := &RateLimiter{
		tokens: make(chan struct{}, max(rps, 1)),
		stop:   make(chan struct{}),
	}
	if rps <= 0 {
		// unlimited — pre-fill and never drain
		return rl
	}
	interval := time.Second / time.Duration(rps)
	go func() {
		ticker := time.NewTicker(interval)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				select {
				case rl.tokens <- struct{}{}:
				default: // bucket full; drop token
				}
			case <-rl.stop:
				return
			}
		}
	}()
	return rl
}

// Wait blocks until a token is available.
func (r *RateLimiter) Wait() { <-r.tokens }

// Stop shuts down the background goroutine.
func (r *RateLimiter) Stop() { r.once.Do(func() { close(r.stop) }) }

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
