package scope

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

// Validator checks whether a target is inside the allowed scope
type Validator struct {
	exact    map[string]struct{} // exact matches e.g. api.example.com
	wildcards []string           // wildcard roots e.g. "example.com" from *.example.com
}

// LoadFromFile reads scope.txt and returns a Validator.
// Lines starting with '#' or empty lines are ignored.
// Lines starting with '*.' are treated as wildcards.
func LoadFromFile(path string) (*Validator, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("cannot open scope file %q: %w", path, err)
	}
	defer f.Close()

	v := &Validator{
		exact: make(map[string]struct{}),
	}

	scanner := bufio.NewScanner(f)
	lineNum := 0
	for scanner.Scan() {
		lineNum++
		line := strings.TrimSpace(scanner.Text())

		// skip comments and blank lines
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		line = strings.ToLower(line)

		if strings.HasPrefix(line, "*.") {
			// wildcard: strip leading "*." and store the root
			root := strings.TrimPrefix(line, "*.")
			if root == "" {
				return nil, fmt.Errorf("scope.txt line %d: invalid wildcard %q", lineNum, line)
			}
			v.wildcards = append(v.wildcards, root)
		} else {
			v.exact[line] = struct{}{}
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("error reading scope file: %w", err)
	}

	if len(v.exact) == 0 && len(v.wildcards) == 0 {
		return nil, fmt.Errorf("scope file %q is empty — add at least one target", path)
	}

	return v, nil
}

// InScope returns true if the given host is within the defined scope.
func (v *Validator) InScope(host string) bool {
	host = strings.ToLower(strings.TrimSpace(host))

	// strip protocol if someone passes a URL
	host = stripProtocol(host)
	// strip path
	if idx := strings.Index(host, "/"); idx != -1 {
		host = host[:idx]
	}

	// exact match
	if _, ok := v.exact[host]; ok {
		return true
	}

	// wildcard match: host must end with "."+root or equal root itself
	for _, root := range v.wildcards {
		if host == root || strings.HasSuffix(host, "."+root) {
			return true
		}
	}

	return false
}

// FilterInScope returns only the hosts that are in scope
func (v *Validator) FilterInScope(hosts []string) []string {
	out := make([]string, 0, len(hosts))
	for _, h := range hosts {
		if v.InScope(h) {
			out = append(out, h)
		}
	}
	return out
}

// stripProtocol removes http:// or https:// prefix
func stripProtocol(s string) string {
	for _, prefix := range []string{"https://", "http://"} {
		if strings.HasPrefix(s, prefix) {
			return strings.TrimPrefix(s, prefix)
		}
	}
	return s
}
