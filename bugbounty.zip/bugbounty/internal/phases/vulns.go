package phases

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/bugbounty/internal/config"
	"github.com/bugbounty/internal/logger"
	"github.com/bugbounty/internal/notify"
	"github.com/bugbounty/internal/output"
	"github.com/bugbounty/internal/runner"
)

// ─────────────────────────────────────────
//  Nuclei JSON schema (partial)
// ─────────────────────────────────────────

type nucleiResult struct {
	TemplateID string `json:"template-id"`
	Info       struct {
		Name        string   `json:"name"`
		Severity    string   `json:"severity"`
		Description string   `json:"description"`
		Tags        []string `json:"tags"`
	} `json:"info"`
	Host    string `json:"host"`
	Matched string `json:"matched-at"`
}

// ─────────────────────────────────────────
//  Result types
// ─────────────────────────────────────────

// VulnResult carries all Phase-4 findings.
type VulnResult struct {
	Findings []output.Finding
}

// ─────────────────────────────────────────
//  Phase entry point
// ─────────────────────────────────────────

// RunVulns executes Phase 4: Vulnerability Testing.
// All scanner categories run in parallel; critical/high alerts are sent immediately.
func RunVulns(
	ctx context.Context,
	cfg *config.Config,
	recon *ReconResult,
	discovery *DiscoveryResult,
	w *output.Writer,
	n *notify.Notifier,
) (*VulnResult, error) {
	logger.Info("VULNS", fmt.Sprintf("Starting vulnerability testing on %d hosts", len(recon.LiveHosts)))

	result := &VulnResult{}
	var mu sync.Mutex

	// addFinding is the single write path — deduplicates and notifies.
	addFinding := func(f output.Finding) {
		w.AddFinding(f) // writer handles dedup internally
		mu.Lock()
		result.Findings = append(result.Findings, f)
		mu.Unlock()

		sev := strings.ToLower(f.Severity)
		if sev == "critical" || sev == "high" {
			n.Alert(f)
			logger.Critical("VULNS", fmt.Sprintf("[%s] %s — %s", f.Severity, f.Title, f.URL))
		} else {
			logger.Success("VULNS", fmt.Sprintf("[%s] %s — %s", f.Severity, f.Title, f.URL))
		}
	}

	var wg sync.WaitGroup

	// ── 1. Nuclei critical+high ────────────────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		for _, f := range runNuclei(ctx, cfg, w, "critical,high") {
			addFinding(f)
		}
	}()

	// ── 2. Dalfox — XSS ───────────────────────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		xssFile, ok := discovery.ParamFiles["xss"]
		if !ok {
			return
		}
		for _, f := range runDalfox(ctx, cfg, w, xssFile) {
			addFinding(f)
		}
	}()

	// ── 3. CORS misconfig ──────────────────────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		for _, f := range runCorsy(ctx, cfg, w) {
			addFinding(f)
		}
	}()

	// ── 4. SecretFinder — exposed secrets in JS ────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		for _, f := range runSecretFinder(ctx, cfg, w, discovery.JSFiles) {
			addFinding(f)
		}
	}()

	// ── 5. SQLi ────────────────────────────────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		sqliFile, ok := discovery.ParamFiles["sqli"]
		if !ok {
			return
		}
		for _, f := range runSQLMap(ctx, cfg, w, sqliFile) {
			addFinding(f)
		}
	}()

	// ── 6. Open redirect ──────────────────────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		redirectFile, ok := discovery.ParamFiles["redirect"]
		if !ok {
			return
		}
		for _, f := range runOpenRedirect(ctx, cfg, w, redirectFile) {
			addFinding(f)
		}
	}()

	wg.Wait()

	// ── 7. Nuclei medium (after critical/high — less urgent) ───────
	for _, f := range runNuclei(ctx, cfg, w, "medium") {
		addFinding(f)
	}

	logger.Success("VULNS", fmt.Sprintf("Phase 4 complete — %d total findings", len(result.Findings)))
	return result, nil
}

// ─────────────────────────────────────────
//  Nuclei
// ─────────────────────────────────────────

func runNuclei(ctx context.Context, cfg *config.Config, w *output.Writer, severity string) []output.Finding {
	hostsFile := w.FilePath("recon", "live_hosts.txt")
	tag := strings.ReplaceAll(severity, ",", "_")
	outFile := w.FilePath("vulns", "nuclei_"+tag+".json")

	lines, err := runner.Run(ctx, "VULNS", cfg.Tools.Nuclei, []string{
		"-l", hostsFile,
		"-severity", severity,
		"-o", outFile,
		"-json",
		"-silent",
		"-rate-limit", fmt.Sprint(cfg.RateLimit),
		"-c", fmt.Sprint(cfg.Threads),
		"-timeout", "10",
		"-retries", "2",
		"-ss", "template-spray", // smarter scan order
		"-stats",
	}, 30*time.Minute)

	if err != nil {
		logger.Warning("VULNS", fmt.Sprintf("nuclei [%s]: %v", severity, err))
	}

	findings := parseNucleiLines(lines)
	logger.Success("VULNS", fmt.Sprintf("nuclei [%s]: %d findings", severity, len(findings)))
	return findings
}

// parseNucleiLines parses nuclei's JSON output (one JSON object per line).
func parseNucleiLines(lines []string) []output.Finding {
	var out []output.Finding
	for _, line := range lines {
		if !strings.HasPrefix(line, "{") {
			continue
		}
		var nr nucleiResult
		if err := json.Unmarshal([]byte(line), &nr); err != nil {
			continue
		}
		out = append(out, output.Finding{
			Tool:        "nuclei",
			Phase:       "vulns",
			Host:        nr.Host,
			URL:         nr.Matched,
			Type:        nr.TemplateID,
			Severity:    nr.Info.Severity,
			Title:       nr.Info.Name,
			Description: nr.Info.Description,
			CVSS:        cvssFromSeverity(nr.Info.Severity),
			Tags:        nr.Info.Tags,
		})
	}
	return out
}

// ─────────────────────────────────────────
//  Dalfox — XSS
// ─────────────────────────────────────────

func runDalfox(ctx context.Context, cfg *config.Config, w *output.Writer, paramsFile string) []output.Finding {
	lines, err := runner.Run(ctx, "VULNS", cfg.Tools.Dalfox, []string{
		"file", paramsFile,
		"--skip-bav",
		"--worker", "20",
		"--timeout", "10",
		"--silence",
		"--output", w.FilePath("vulns", "dalfox_xss.txt"),
	}, 20*time.Minute)
	if err != nil {
		logger.Warning("VULNS", fmt.Sprintf("dalfox: %v", err))
	}

	var findings []output.Finding
	for _, line := range lines {
		// dalfox marks verified XSS with [V]
		if strings.Contains(line, "[V]") || strings.Contains(line, "POC") {
			findings = append(findings, output.Finding{
				Tool:     "dalfox",
				Phase:    "vulns",
				Type:     "XSS",
				Severity: "high",
				Title:    "Cross-Site Scripting (XSS)",
				URL:      extractURL(line),
				Evidence: line,
				CVSS:     7.2,
				PoC:      line,
			})
		}
	}
	logger.Success("VULNS", fmt.Sprintf("dalfox: %d XSS findings", len(findings)))
	return findings
}

// ─────────────────────────────────────────
//  Corsy — CORS
// ─────────────────────────────────────────

func runCorsy(ctx context.Context, cfg *config.Config, w *output.Writer) []output.Finding {
	hostsFile := w.FilePath("recon", "live_hosts.txt")
	lines, err := runner.Run(ctx, "VULNS", "python3", []string{
		cfg.Tools.Corsy,
		"-i", hostsFile,
		"-t", "10",
		"--headers", "User-Agent: BugBounty/1.0",
	}, 15*time.Minute)
	if err != nil {
		logger.Warning("VULNS", fmt.Sprintf("corsy: %v", err))
	}

	var findings []output.Finding
	for _, line := range lines {
		if strings.Contains(line, "Vulnerable") {
			findings = append(findings, output.Finding{
				Tool:        "corsy",
				Phase:       "vulns",
				Type:        "CORS_MISCONFIGURATION",
				Severity:    "medium",
				Title:       "CORS Misconfiguration",
				URL:         extractURL(line),
				Evidence:    line,
				CVSS:        5.4,
				Description: "The server returns permissive CORS headers that may allow cross-origin data theft.",
				PoC: fmt.Sprintf(
					"curl -H 'Origin: https://evil.com' -I '%s'", extractURL(line)),
			})
		}
	}
	w.WriteLines("vulns", "cors_findings.txt", lines)
	return findings
}

// ─────────────────────────────────────────
//  SecretFinder
// ─────────────────────────────────────────

func runSecretFinder(ctx context.Context, cfg *config.Config, w *output.Writer, jsFiles []string) []output.Finding {
	limit := intMin(len(jsFiles), 100)
	var (
		findings []output.Finding
		mu       sync.Mutex
		sem      = make(chan struct{}, 8)
		wg       sync.WaitGroup
	)

	for _, js := range jsFiles[:limit] {
		wg.Add(1)
		go func(jsURL string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			lines, err := runner.Run(ctx, "VULNS", "python3", []string{
				cfg.Tools.Secretfinder, "-i", jsURL, "-o", "cli",
			}, 90*time.Second)
			if err != nil {
				return
			}
			for _, line := range lines {
				if line == "" || strings.Contains(line, "No data") {
					continue
				}
				mu.Lock()
				findings = append(findings, output.Finding{
					Tool:        "secretfinder",
					Phase:       "vulns",
					Type:        "SECRET_EXPOSURE",
					Severity:    "high",
					Title:       "Exposed Secret / API Key",
					URL:         jsURL,
					Evidence:    line,
					CVSS:        7.5,
					Description: "A secret, API key, or token was found in a publicly accessible JS file.",
					PoC:         fmt.Sprintf("curl -s '%s' | grep -iE 'key|token|secret|password'", jsURL),
				})
				mu.Unlock()
			}
		}(js)
	}
	wg.Wait()

	logger.Success("VULNS", fmt.Sprintf("secretfinder: %d secrets found", len(findings)))
	return findings
}

// ─────────────────────────────────────────
//  SQLMap
// ─────────────────────────────────────────

func runSQLMap(ctx context.Context, cfg *config.Config, w *output.Writer, paramsFile string) []output.Finding {
	lines, err := runner.Run(ctx, "VULNS", cfg.Tools.Sqlmap, []string{
		"-m", paramsFile,
		"--batch",
		"--level", "2",
		"--risk", "2",
		"--random-agent",
		"--threads", "5",
		"--output-dir", w.FilePath("vulns", "sqlmap"),
		"--forms",
	}, 30*time.Minute)
	if err != nil {
		logger.Warning("VULNS", fmt.Sprintf("sqlmap: %v", err))
	}

	var findings []output.Finding
	for _, line := range lines {
		if strings.Contains(line, "is vulnerable") || strings.Contains(line, "Parameter:") {
			findings = append(findings, output.Finding{
				Tool:        "sqlmap",
				Phase:       "vulns",
				Type:        "SQL_INJECTION",
				Severity:    "critical",
				Title:       "SQL Injection",
				Evidence:    line,
				CVSS:        9.8,
				Description: "The application is vulnerable to SQL Injection, potentially allowing full database access.",
			})
		}
	}
	logger.Success("VULNS", fmt.Sprintf("sqlmap: %d SQLi findings", len(findings)))
	return findings
}

// ─────────────────────────────────────────
//  Open Redirect
// ─────────────────────────────────────────

func runOpenRedirect(ctx context.Context, cfg *config.Config, w *output.Writer, paramsFile string) []output.Finding {
	// qsreplace injects evil.com into redirect params then curl checks
	// the Location header.
	lines, err := runner.Run(ctx, "VULNS", "bash", []string{
		"-c",
		fmt.Sprintf(
			`cat %s | grep -i "redirect\|url\|next\|return" `+
				`| qsreplace 'https://evil.com' `+
				`| while read u; do `+
				`  loc=$(curl -s -o /dev/null -w '%%{redirect_url}' -m5 "$u"); `+
				`  echo "$loc $u"; `+
				`done | grep 'evil.com'`,
			paramsFile,
		),
	}, 15*time.Minute)
	if err != nil {
		logger.Warning("VULNS", fmt.Sprintf("open redirect: %v", err))
	}

	var findings []output.Finding
	for _, line := range lines {
		if strings.Contains(line, "evil.com") {
			url := extractURL(line)
			findings = append(findings, output.Finding{
				Tool:        "qsreplace+curl",
				Phase:       "vulns",
				Type:        "OPEN_REDIRECT",
				Severity:    "medium",
				Title:       "Open Redirect",
				URL:         url,
				Evidence:    line,
				CVSS:        6.1,
				Description: "The application redirects users to attacker-controlled URLs.",
				PoC:         fmt.Sprintf("curl -v '%s'", url),
			})
		}
	}
	w.WriteLines("vulns", "open_redirect.txt", lines)
	logger.Success("VULNS", fmt.Sprintf("open redirect: %d findings", len(findings)))
	return findings
}

// ─────────────────────────────────────────
//  Shared utilities (used by validation.go too)
// ─────────────────────────────────────────

// cvssFromSeverity returns a representative CVSS base score.
func cvssFromSeverity(sev string) float64 {
	switch strings.ToLower(sev) {
	case "critical":
		return 9.5
	case "high":
		return 7.5
	case "medium":
		return 5.0
	case "low":
		return 2.5
	default:
		return 0.0
	}
}

// extractURL pulls the first http(s) token from a line, or returns the whole line.
func extractURL(line string) string {
	for _, token := range strings.Fields(line) {
		if strings.HasPrefix(token, "http") {
			return token
		}
	}
	return line
}
