package phases

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/bugbounty/internal/config"
	"github.com/bugbounty/internal/logger"
	"github.com/bugbounty/internal/output"
	"github.com/bugbounty/internal/runner"
	"github.com/bugbounty/internal/scope"
)

// ─────────────────────────────────────────
//  Result types
// ─────────────────────────────────────────

// ReconResult carries all Phase-1 data downstream.
type ReconResult struct {
	Subdomains []string
	LiveHosts  []string // URLs confirmed alive by httpx
	IPs        []string
}

// ─────────────────────────────────────────
//  Phase entry point
// ─────────────────────────────────────────

// RunRecon executes Phase 1: Reconnaissance.
// It runs all subdomain tools in parallel, merges results,
// filters by scope, then probes for live web servers.
func RunRecon(
	ctx context.Context,
	target string,
	cfg *config.Config,
	sv *scope.Validator,
	w *output.Writer,
) (*ReconResult, error) {
	logger.Info("RECON", fmt.Sprintf("Starting for target: %s", target))

	type partial struct {
		name  string
		lines []string
		err   error
	}

	ch := make(chan partial, 8)
	var wg sync.WaitGroup

	// ── subfinder ──────────────────────────────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		lines, err := runner.Run(ctx, "RECON", cfg.Tools.Subfinder, []string{
			"-d", target,
			"-all",          // use all sources
			"-silent",
			"-t", fmt.Sprint(cfg.Threads),
		}, toolTimeout(cfg))
		ch <- partial{"subfinder", lines, err}
	}()

	// ── amass (passive only — faster, less noise) ──────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		lines, err := runner.Run(ctx, "RECON", cfg.Tools.Amass, []string{
			"enum", "-passive",
			"-d", target,
			"-silent",
			"-timeout", fmt.Sprint(cfg.Timeout),
		}, toolTimeout(cfg))
		ch <- partial{"amass", lines, err}
	}()

	// ── assetfinder ────────────────────────────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		lines, err := runner.Run(ctx, "RECON", cfg.Tools.Assetfinder, []string{
			"--subs-only", target,
		}, toolTimeout(cfg))
		ch <- partial{"assetfinder", lines, err}
	}()

	// ── crt.sh (certificate transparency) ─────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		lines, err := queryCrtSh(ctx, target)
		ch <- partial{"crt.sh", lines, err}
	}()

	// ── chaos (ProjectDiscovery DB) — only if key is configured ───
	if cfg.APIs.Chaos != "" {
		wg.Add(1)
		go func() {
			defer wg.Done()
			lines, err := runner.Run(ctx, "RECON", "chaos", []string{
				"-d", target,
				"-silent",
				"-key", cfg.APIs.Chaos,
			}, toolTimeout(cfg))
			ch <- partial{"chaos", lines, err}
		}()
	}

	// ── close channel when all goroutines finish ───────────────────
	go func() {
		wg.Wait()
		close(ch)
	}()

	// ── collect & merge ────────────────────────────────────────────
	var all []string
	for p := range ch {
		if p.err != nil {
			logger.Warning("RECON", fmt.Sprintf("%s: %v", p.name, p.err))
			// don't abort — other tools may have succeeded
		}
		all = append(all, p.lines...)
	}

	// normalise to lowercase
	for i, s := range all {
		all[i] = strings.ToLower(strings.TrimSpace(s))
	}

	// deduplicate
	subdomains := runner.Deduplicate(all)

	// scope filter — always validate before touching anything
	subdomains = sv.FilterInScope(subdomains)

	logger.Success("RECON", fmt.Sprintf(
		"%d unique in-scope subdomains discovered", len(subdomains)))

	if err := w.WriteLines("recon", "subdomains.txt", subdomains); err != nil {
		return nil, fmt.Errorf("write subdomains: %w", err)
	}

	if len(subdomains) == 0 {
		logger.Warning("RECON", "No subdomains found — verify scope.txt and tool availability")
		return &ReconResult{}, nil
	}

	// ── DNS resolution ─────────────────────────────────────────────
	ips, err := runDnsx(ctx, cfg, w)
	if err != nil {
		logger.Warning("RECON", fmt.Sprintf("dnsx: %v", err))
	}

	// ── httpx: find live web servers ───────────────────────────────
	live, err := runHttpx(ctx, cfg, w)
	if err != nil {
		logger.Warning("RECON", fmt.Sprintf("httpx: %v", err))
	}

	logger.Success("RECON", fmt.Sprintf(
		"%d live hosts | %d IPs resolved", len(live), len(ips)))

	return &ReconResult{
		Subdomains: subdomains,
		LiveHosts:  live,
		IPs:        ips,
	}, nil
}

// ─────────────────────────────────────────
//  Tool helpers
// ─────────────────────────────────────────

// runDnsx resolves all subdomains and writes ips.txt.
func runDnsx(ctx context.Context, cfg *config.Config, w *output.Writer) ([]string, error) {
	subFile := w.FilePath("recon", "subdomains.txt")
	lines, err := runner.Run(ctx, "RECON", cfg.Tools.Dnsx, []string{
		"-l", subFile,
		"-silent",
		"-a",              // resolve A records
		"-resp",           // include IP in output
		"-t", fmt.Sprint(cfg.Threads),
	}, toolTimeout(cfg))
	if err != nil && len(lines) == 0 {
		return nil, err
	}

	// dnsx output: "sub.example.com [1.2.3.4]"
	var ips []string
	for _, line := range lines {
		if idx := strings.Index(line, "["); idx != -1 {
			ip := strings.Trim(line[idx:], "[]")
			ips = append(ips, ip)
		}
	}
	ips = runner.Deduplicate(ips)
	w.WriteLines("recon", "ips.txt", ips)
	return ips, nil
}

// runHttpx probes subdomains and returns live URL list.
func runHttpx(ctx context.Context, cfg *config.Config, w *output.Writer) ([]string, error) {
	subFile := w.FilePath("recon", "subdomains.txt")

	lines, err := runner.Run(ctx, "RECON", cfg.Tools.Httpx, []string{
		"-l", subFile,
		"-silent",
		"-threads", fmt.Sprint(cfg.Threads),
		"-timeout", "10",
		"-rate-limit", fmt.Sprint(cfg.RateLimit),
		"-follow-redirects",
		"-status-code",
		"-title",
		"-tech-detect",
		"-json",           // structured output for richer data
	}, 20*time.Minute)

	if err != nil && len(lines) == 0 {
		return nil, err
	}

	var live []string
	for _, line := range lines {
		// httpx -json lines look like: {"url":"https://...","status-code":200,...}
		if strings.HasPrefix(line, "{") {
			var obj struct {
				URL string `json:"url"`
			}
			if jsonErr := json.Unmarshal([]byte(line), &obj); jsonErr == nil && obj.URL != "" {
				live = append(live, obj.URL)
				continue
			}
		}
		// fallback: plain URL line
		if strings.HasPrefix(line, "http") {
			live = append(live, line)
		}
	}

	live = runner.Deduplicate(live)
	if writeErr := w.WriteLines("recon", "live_hosts.txt", live); writeErr != nil {
		return nil, writeErr
	}
	return live, nil
}

// queryCrtSh fetches subdomains from the crt.sh certificate transparency log.
func queryCrtSh(ctx context.Context, domain string) ([]string, error) {
	url := fmt.Sprintf("https://crt.sh/?q=%%25.%s&output=json", domain)

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, fmt.Errorf("build request: %w", err)
	}
	req.Header.Set("User-Agent", "BugBounty-Framework/1.0")
	req.Header.Set("Accept", "application/json")

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("crt.sh GET: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("crt.sh returned HTTP %d", resp.StatusCode)
	}

	var entries []struct {
		NameValue string `json:"name_value"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&entries); err != nil {
		return nil, fmt.Errorf("decode crt.sh response: %w", err)
	}

	seen := make(map[string]struct{})
	var domains []string
	for _, e := range entries {
		for _, name := range strings.Split(e.NameValue, "\n") {
			name = strings.ToLower(strings.TrimSpace(name))
			name = strings.TrimPrefix(name, "*.")
			if name == "" || !strings.Contains(name, domain) {
				continue
			}
			if _, dup := seen[name]; dup {
				continue
			}
			seen[name] = struct{}{}
			domains = append(domains, name)
		}
	}

	logger.Success("RECON", fmt.Sprintf("crt.sh: %d subdomains", len(domains)))
	return domains, nil
}

// toolTimeout converts cfg.Timeout (minutes) to a time.Duration.
func toolTimeout(cfg *config.Config) time.Duration {
	if cfg.Timeout <= 0 {
		return 10 * time.Minute
	}
	return time.Duration(cfg.Timeout) * time.Minute
}
