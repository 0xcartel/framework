package phases

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/bugbounty/internal/config"
	"github.com/bugbounty/internal/logger"
	"github.com/bugbounty/internal/output"
	"github.com/bugbounty/internal/runner"
)

// ─────────────────────────────────────────
//  Result types
// ─────────────────────────────────────────

// TechStack records detected technologies for one host.
type TechStack struct {
	Host         string
	Technologies []string
	IsWordPress  bool
	HasPHP       bool
	HasAPI       bool
	HasNodeJS    bool
}

// DiscoveryResult carries all Phase-2 data downstream.
type DiscoveryResult struct {
	AllURLs    []string
	JSFiles    []string
	Endpoints  []string // extracted from JS via linkfinder
	ParamFiles map[string]string // gf pattern → file path
	TechStacks map[string]*TechStack
}

// ─────────────────────────────────────────
//  Phase entry point
// ─────────────────────────────────────────

// RunDiscovery executes Phase 2: URL Discovery & Fingerprinting.
func RunDiscovery(
	ctx context.Context,
	cfg *config.Config,
	recon *ReconResult,
	w *output.Writer,
) (*DiscoveryResult, error) {
	logger.Info("DISCOVERY", fmt.Sprintf(
		"Starting on %d live hosts", len(recon.LiveHosts)))

	result := &DiscoveryResult{
		ParamFiles: make(map[string]string),
		TechStacks: make(map[string]*TechStack),
	}

	if len(recon.LiveHosts) == 0 {
		logger.Warning("DISCOVERY", "No live hosts — skipping")
		return result, nil
	}

	type partial struct {
		name  string
		lines []string
		err   error
	}
	ch := make(chan partial, 6)
	var wg sync.WaitGroup

	hostsFile := w.FilePath("recon", "live_hosts.txt")

	// ── gau — all URLs from Wayback + Common Crawl + OTX ──────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		var lines []string
		for _, host := range recon.LiveHosts {
			l, err := runner.Run(ctx, "DISCOVERY", cfg.Tools.Gau, []string{
				"--threads", "5",
				"--subs",
				host,
			}, 10*time.Minute)
			if err != nil {
				logger.Debug("DISCOVERY", fmt.Sprintf("gau %s: %v", host, err))
			}
			lines = append(lines, l...)
		}
		ch <- partial{"gau", lines, nil}
	}()

	// ── waybackurls ────────────────────────────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		var lines []string
		for _, sub := range recon.Subdomains {
			l, err := runner.Run(ctx, "DISCOVERY", cfg.Tools.Waybackurls, []string{sub}, 8*time.Minute)
			if err != nil {
				logger.Debug("DISCOVERY", fmt.Sprintf("waybackurls %s: %v", sub, err))
			}
			lines = append(lines, l...)
		}
		ch <- partial{"waybackurls", lines, nil}
	}()

	// ── katana — modern JS-aware crawler ──────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		lines, err := runner.Run(ctx, "DISCOVERY", cfg.Tools.Katana, []string{
			"-list", hostsFile,
			"-silent",
			"-d", "5",            // crawl depth
			"-jc",                // parse JS
			"-fx",                // extract forms
			"-ef", "png,jpg,gif,svg,ico,woff,woff2,ttf,eot,css",
			"-c", fmt.Sprint(cfg.Threads),
			"-rl", fmt.Sprint(cfg.RateLimit),
			"-timeout", "10",
		}, 20*time.Minute)
		ch <- partial{"katana", lines, err}
	}()

	// ── hakrawler — fast additional crawl ─────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		lines, err := runner.Run(ctx, "DISCOVERY", cfg.Tools.Hakrawler, []string{
			"-url-file", hostsFile,
			"-depth", "3",
			"-subs",
			"-insecure",
		}, 15*time.Minute)
		ch <- partial{"hakrawler", lines, err}
	}()

	go func() {
		wg.Wait()
		close(ch)
	}()

	// ── collect ────────────────────────────────────────────────────
	var allURLs []string
	for p := range ch {
		if p.err != nil {
			logger.Warning("DISCOVERY", fmt.Sprintf("%s: %v", p.name, p.err))
		}
		allURLs = append(allURLs, p.lines...)
	}

	allURLs = runner.Deduplicate(allURLs)
	result.AllURLs = allURLs
	logger.Success("DISCOVERY", fmt.Sprintf("%d unique URLs collected", len(allURLs)))

	if err := w.WriteLines("discovery", "all_urls.txt", allURLs); err != nil {
		return nil, fmt.Errorf("write all_urls: %w", err)
	}

	// ── JS files ───────────────────────────────────────────────────
	result.JSFiles = filterByExt(allURLs, ".js")
	if err := w.WriteLines("discovery", "js_files.txt", result.JSFiles); err != nil {
		logger.Warning("DISCOVERY", fmt.Sprintf("write js_files: %v", err))
	}
	logger.Info("DISCOVERY", fmt.Sprintf("%d JS files found", len(result.JSFiles)))

	// ── gf patterns — extract interesting params ───────────────────
	result.ParamFiles = runGF(ctx, cfg, w, allURLs)

	// ── tech fingerprinting ────────────────────────────────────────
	result.TechStacks = fingerprintTechs(recon.LiveHosts, allURLs)

	// ── linkfinder — endpoints from JS ────────────────────────────
	result.Endpoints = runLinkFinder(ctx, cfg, w, result.JSFiles)

	return result, nil
}

// ─────────────────────────────────────────
//  Helpers
// ─────────────────────────────────────────

// filterByExt returns URLs whose path ends with ext, ignoring query strings.
func filterByExt(urls []string, ext string) []string {
	out := make([]string, 0, len(urls)/10)
	ext = strings.ToLower(ext)
	for _, u := range urls {
		base := u
		if idx := strings.IndexByte(u, '?'); idx != -1 {
			base = u[:idx]
		}
		if strings.HasSuffix(strings.ToLower(base), ext) {
			out = append(out, u)
		}
	}
	return out
}

// runGF applies gf patterns to extract parameter URLs by vulnerability class.
func runGF(ctx context.Context, cfg *config.Config, w *output.Writer, urls []string) map[string]string {
	patterns := []string{
		"xss", "sqli", "ssrf", "redirect", "rce", "lfi", "ssti", "idor",
	}

	urlsFile := w.FilePath("discovery", "all_urls.txt")
	result := make(map[string]string, len(patterns))

	for _, pattern := range patterns {
		lines, err := runner.Run(ctx, "DISCOVERY", cfg.Tools.Gf, []string{
			pattern, urlsFile,
		}, 3*time.Minute)
		if err != nil {
			logger.Debug("DISCOVERY", fmt.Sprintf("gf %s: %v", pattern, err))
			continue
		}
		filename := fmt.Sprintf("params_%s.txt", pattern)
		if writeErr := w.WriteLines("discovery", filename, lines); writeErr != nil {
			logger.Warning("DISCOVERY", fmt.Sprintf("write %s: %v", filename, writeErr))
			continue
		}
		result[pattern] = w.FilePath("discovery", filename)
		logger.Success("DISCOVERY", fmt.Sprintf("gf %s → %d params", pattern, len(lines)))
	}
	return result
}

// fingerprintTechs detects the technology stack for each live host
// by examining URL patterns. A full webanalyze pass would be ideal
// for production use, but this heuristic is fast and zero-dependency.
func fingerprintTechs(hosts, urls []string) map[string]*TechStack {
	stacks := make(map[string]*TechStack, len(hosts))

	for _, host := range hosts {
		stack := &TechStack{Host: host}

		for _, u := range urls {
			if !strings.Contains(u, stripProto(host)) {
				continue
			}
			ul := strings.ToLower(u)

			if strings.Contains(ul, "wp-content") || strings.Contains(ul, "wp-admin") ||
				strings.Contains(ul, "wp-login") || strings.Contains(ul, "wp-json") {
				if !stack.IsWordPress {
					stack.IsWordPress = true
					stack.Technologies = append(stack.Technologies, "WordPress")
				}
			}
			if strings.Contains(ul, ".php") {
				if !stack.HasPHP {
					stack.HasPHP = true
					stack.Technologies = append(stack.Technologies, "PHP")
				}
			}
			if strings.Contains(ul, "/api/") || strings.Contains(ul, "/v1/") ||
				strings.Contains(ul, "/v2/") || strings.Contains(ul, "/graphql") {
				if !stack.HasAPI {
					stack.HasAPI = true
					stack.Technologies = append(stack.Technologies, "REST API")
				}
			}
			if strings.Contains(ul, "node_modules") || strings.Contains(ul, "express") {
				if !stack.HasNodeJS {
					stack.HasNodeJS = true
					stack.Technologies = append(stack.Technologies, "Node.js")
				}
			}
		}

		stacks[host] = stack
	}
	return stacks
}

// runLinkFinder extracts API endpoints from JS files.
// It limits to 100 files to avoid running forever.
func runLinkFinder(ctx context.Context, cfg *config.Config, w *output.Writer, jsFiles []string) []string {
	limit := 100
	if len(jsFiles) < limit {
		limit = len(jsFiles)
	}

	var (
		mu        sync.Mutex
		endpoints []string
		sem       = make(chan struct{}, 10) // max 10 concurrent
		wg        sync.WaitGroup
	)

	for _, js := range jsFiles[:limit] {
		wg.Add(1)
		go func(jsURL string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			lines, err := runner.Run(ctx, "DISCOVERY", "python3", []string{
				cfg.Tools.Linkfinder, "-i", jsURL, "-o", "cli",
			}, 90*time.Second)
			if err != nil {
				return
			}
			mu.Lock()
			endpoints = append(endpoints, lines...)
			mu.Unlock()
		}(js)
	}
	wg.Wait()

	endpoints = runner.Deduplicate(endpoints)
	if err := w.WriteLines("discovery", "js_endpoints.txt", endpoints); err != nil {
		logger.Warning("DISCOVERY", fmt.Sprintf("write js_endpoints: %v", err))
	}
	logger.Success("DISCOVERY", fmt.Sprintf("LinkFinder: %d endpoints", len(endpoints)))
	return endpoints
}

// stripProto removes https:// or http:// prefix for substring matching.
func stripProto(s string) string {
	for _, p := range []string{"https://", "http://"} {
		s = strings.TrimPrefix(s, p)
	}
	return s
}
