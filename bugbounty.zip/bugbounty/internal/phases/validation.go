package phases

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/bugbounty/internal/config"
	"github.com/bugbounty/internal/logger"
	"github.com/bugbounty/internal/output"
	"github.com/bugbounty/internal/runner"
)

// ─────────────────────────────────────────
//  Result types
// ─────────────────────────────────────────

// ValidationResult carries Phase-5 output.
type ValidationResult struct {
	ValidatedFindings []output.Finding
	Duplicates        int
	FalsePositives    int
}

// ─────────────────────────────────────────
//  Phase entry point
// ─────────────────────────────────────────

// RunValidation executes Phase 5: Validation & Deduplication.
//
// Steps:
//  1. Deduplicate findings by (URL, Type) key
//  2. Filter known false-positive patterns
//  3. Enrich every finding with a CVSS score and a PoC command
//  4. Sort by severity (critical → info)
//  5. Write per-severity text files for quick review
//  6. Persist the final JSON findings file
func RunValidation(
	ctx context.Context,
	cfg *config.Config,
	vulns *VulnResult,
	w *output.Writer,
) (*ValidationResult, error) {
	initial := len(vulns.Findings)
	logger.Info("VALIDATION", fmt.Sprintf("Validating %d raw findings...", initial))

	// 1. Deduplicate
	deduped := deduplicateFindings(vulns.Findings)
	dupsRemoved := initial - len(deduped)

	// 2. False-positive filter
	validated, fpRemoved := filterFalsePositives(deduped)

	// 3. Enrich
	for i := range validated {
		validated[i] = enrich(validated[i])
	}

	// 4. Sort
	sorted := sortBySeverity(validated)

	// 5. Write per-severity files
	if err := writeBySevertiy(w, sorted); err != nil {
		logger.Warning("VALIDATION", fmt.Sprintf("write by severity: %v", err))
	}

	// 6. Run anew (new-findings delta vs previous runs)
	runAnew(ctx, cfg, w)

	// 7. Persist JSON
	if err := w.SaveFindings(); err != nil {
		return nil, fmt.Errorf("save findings: %w", err)
	}

	result := &ValidationResult{
		ValidatedFindings: sorted,
		Duplicates:        dupsRemoved,
		FalsePositives:    fpRemoved,
	}

	logger.Success("VALIDATION", fmt.Sprintf(
		"%d valid | %d duplicates removed | %d false-positives removed",
		len(sorted), dupsRemoved, fpRemoved))

	return result, nil
}

// ─────────────────────────────────────────
//  Deduplication
// ─────────────────────────────────────────

// deduplicateFindings removes findings with identical (URL, Type) pairs.
// The first occurrence wins.
func deduplicateFindings(findings []output.Finding) []output.Finding {
	seen := make(map[string]struct{}, len(findings))
	out := make([]output.Finding, 0, len(findings))
	for _, f := range findings {
		key := fmt.Sprintf("%s|%s", strings.ToLower(f.URL), strings.ToLower(f.Type))
		if _, dup := seen[key]; dup {
			continue
		}
		seen[key] = struct{}{}
		out = append(out, f)
	}
	return out
}

// ─────────────────────────────────────────
//  False-positive filter
// ─────────────────────────────────────────

// falsePositiveURLPatterns are URL substrings that reliably indicate
// a scanner hit a test/mock endpoint rather than a real one.
var falsePositiveURLPatterns = []string{
	"localhost", "127.0.0.1", "0.0.0.0",
	"example.com", "test.test", "placeholder",
	"FUZZ", "{{", "}}",
}

// falsePositiveTitlePatterns are finding title substrings that are
// almost always informational noise.
var falsePositiveTitlePatterns = []string{
	"deprecated ssl", "weak cipher",
	"missing header",   // too noisy without manual triage
}

func filterFalsePositives(findings []output.Finding) ([]output.Finding, int) {
	out := make([]output.Finding, 0, len(findings))
	removed := 0
	for _, f := range findings {
		if isFalsePositive(f) {
			removed++
			logger.Debug("VALIDATION", fmt.Sprintf("FP removed: %s — %s", f.Type, f.URL))
			continue
		}
		out = append(out, f)
	}
	return out, removed
}

func isFalsePositive(f output.Finding) bool {
	urlLower := strings.ToLower(f.URL)
	for _, pat := range falsePositiveURLPatterns {
		if strings.Contains(urlLower, pat) {
			return true
		}
	}
	titleLower := strings.ToLower(f.Title)
	for _, pat := range falsePositiveTitlePatterns {
		if strings.Contains(titleLower, pat) {
			return true
		}
	}
	return false
}

// ─────────────────────────────────────────
//  Enrichment
// ─────────────────────────────────────────

// enrich fills in missing CVSS scores and generates a PoC command when absent.
func enrich(f output.Finding) output.Finding {
	if f.CVSS == 0 {
		f.CVSS = cvssFromSeverity(f.Severity)
	}
	if f.PoC == "" {
		f.PoC = generatePoC(f)
	}
	if f.Timestamp.IsZero() {
		f.Timestamp = time.Now().UTC()
	}
	return f
}

// generatePoC creates a ready-to-run shell command that demonstrates the issue.
func generatePoC(f output.Finding) string {
	switch f.Type {
	case "XSS":
		return fmt.Sprintf(`curl -s '%s' | grep -i '<script'`, f.URL)
	case "SQL_INJECTION":
		return fmt.Sprintf(`sqlmap -u '%s' --batch --level=2 --risk=2`, f.URL)
	case "CORS_MISCONFIGURATION":
		return fmt.Sprintf(`curl -H 'Origin: https://evil.com' -I '%s'`, f.URL)
	case "SECRET_EXPOSURE":
		return fmt.Sprintf(`curl -s '%s' | grep -iE 'api_key|secret|token|password'`, f.URL)
	case "OPEN_REDIRECT":
		return fmt.Sprintf(`curl -v '%s'`, f.URL)
	default:
		return fmt.Sprintf(`# Manual verification required: %s`, f.URL)
	}
}

// ─────────────────────────────────────────
//  Sorting
// ─────────────────────────────────────────

var severityRank = map[string]int{
	"critical": 0,
	"high":     1,
	"medium":   2,
	"low":      3,
	"info":     4,
	"":         5,
}

// sortBySeverity returns findings ordered critical → info (stable, in-place copy).
func sortBySeverity(findings []output.Finding) []output.Finding {
	out := make([]output.Finding, len(findings))
	copy(out, findings)
	// insertion sort — finding lists are small enough that O(n²) is fine.
	for i := 1; i < len(out); i++ {
		key := out[i]
		j := i - 1
		for j >= 0 && rankOf(out[j]) > rankOf(key) {
			out[j+1] = out[j]
			j--
		}
		out[j+1] = key
	}
	return out
}

func rankOf(f output.Finding) int {
	r, ok := severityRank[strings.ToLower(f.Severity)]
	if !ok {
		return 5
	}
	return r
}

// ─────────────────────────────────────────
//  Per-severity output files
// ─────────────────────────────────────────

func writeBySevertiy(w *output.Writer, findings []output.Finding) error {
	buckets := map[string][]string{}
	for _, f := range findings {
		sev := strings.ToLower(f.Severity)
		line := fmt.Sprintf("[%s] %-30s %s", f.Type, f.Title, f.URL)
		buckets[sev] = append(buckets[sev], line)
	}
	for sev, lines := range buckets {
		filename := fmt.Sprintf("vulns_%s.txt", sev)
		if err := w.WriteLines("validation", filename, lines); err != nil {
			return err
		}
	}
	return nil
}

// ─────────────────────────────────────────
//  anew — delta vs previous runs
// ─────────────────────────────────────────

// runAnew pipes the findings JSON through anew so only *new* findings
// (not seen in previous scans) are highlighted in the terminal.
func runAnew(ctx context.Context, cfg *config.Config, w *output.Writer) {
	allFile := w.FilePath("reports", "findings.json")

	_, err := runner.Run(ctx, "VALIDATION", cfg.Tools.Anew, []string{allFile},
		2*time.Minute)
	if err != nil {
		// anew is optional; log at DEBUG and continue.
		logger.Debug("VALIDATION", fmt.Sprintf("anew: %v", err))
	}
}
