package phases

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/bugbounty/internal/config"
	"github.com/bugbounty/internal/logger"
	"github.com/bugbounty/internal/output"
	"github.com/bugbounty/internal/runner"
)

// ─────────────────────────────────────────
//  Result types
// ─────────────────────────────────────────

// ScanResult carries all Phase-3 data downstream.
type ScanResult struct {
	OpenPorts    map[string][]string // host → []port
	Directories  []string
	APIEndpoints []string
}

// ─────────────────────────────────────────
//  Phase entry point
// ─────────────────────────────────────────

// RunScanning executes Phase 3: Smart Scanning.
// Strategy:
//  1. naabu fast-scans every host for a curated port list
//  2. nmap deep-scans only hosts with "interesting" open ports
//  3. ffuf fuzzes directories on the first N live hosts
//  4. wpscan runs only when WordPress was detected in Phase 2
func RunScanning(
	ctx context.Context,
	cfg *config.Config,
	recon *ReconResult,
	discovery *DiscoveryResult,
	w *output.Writer,
) (*ScanResult, error) {
	logger.Info("SCANNING", "Starting smart scanning phase")

	result := &ScanResult{
		OpenPorts: make(map[string][]string),
	}

	var (
		mu sync.Mutex
		wg sync.WaitGroup
	)

	// ── naabu — fast port scan ─────────────────────────────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		ports := runNaabu(ctx, cfg, w)
		mu.Lock()
		for host, ps := range ports {
			result.OpenPorts[host] = ps
		}
		mu.Unlock()
	}()

	// ── ffuf — directory fuzzing (capped at 20 hosts) ─────────────
	wg.Add(1)
	go func() {
		defer wg.Done()
		limit := intMin(len(recon.LiveHosts), 20)
		dirs := runFFUF(ctx, cfg, w, recon.LiveHosts[:limit])
		mu.Lock()
		result.Directories = dirs
		mu.Unlock()
	}()

	wg.Wait()

	// ── nmap — targeted deep scan on interesting ports ─────────────
	runNmapTargeted(ctx, cfg, w, result.OpenPorts)

	// ── wpscan — only when WordPress detected ─────────────────────
	for _, stack := range discovery.TechStacks {
		if stack.IsWordPress {
			runWPScan(ctx, cfg, w, stack.Host)
		}
	}

	// ── API endpoint scan ──────────────────────────────────────────
	result.APIEndpoints = runAPIDiscovery(ctx, cfg, w, discovery)

	logger.Success("SCANNING", fmt.Sprintf(
		"Scanning done — %d hosts with open ports | %d directories",
		len(result.OpenPorts), len(result.Directories)))

	return result, nil
}

// ─────────────────────────────────────────
//  naabu
// ─────────────────────────────────────────

// interestingPorts is the fast-scan target list.
// Covers: HTTP/S variants, common dev ports, databases, mail, SSH/FTP.
const interestingPorts = "21,22,25,80,443,587,3000,3306,4000,4443,5000," +
	"5432,6379,8080,8081,8443,8888,9090,9200,27017"

func runNaabu(ctx context.Context, cfg *config.Config, w *output.Writer) map[string][]string {
	// naabu needs plain hostnames/IPs — strip https:// and http://
	// live_hosts.txt may contain full URLs from httpx
	rawHosts, _ := w.ReadLines("recon", "live_hosts.txt")
	var cleanHosts []string
	for _, h := range rawHosts {
		h = strings.TrimPrefix(h, "https://")
		h = strings.TrimPrefix(h, "http://")
		// strip path/port if present
		if idx := strings.IndexByte(h, '/'); idx != -1 {
			h = h[:idx]
		}
		if idx := strings.IndexByte(h, ':'); idx != -1 {
			h = h[:idx]
		}
		if h != "" {
			cleanHosts = append(cleanHosts, h)
		}
	}
	cleanHosts = runner.Deduplicate(cleanHosts)

	// write clean hosts to a separate file for naabu
	plainFile := w.FilePath("recon", "hosts_plain.txt")
	if err := w.WriteLines("recon", "hosts_plain.txt", cleanHosts); err != nil {
		logger.Warning("SCANNING", fmt.Sprintf("write hosts_plain: %v", err))
	}

	lines, err := runner.Run(ctx, "SCANNING", cfg.Tools.Naabu, []string{
		"-list", plainFile,
		"-p", interestingPorts,
		"-rate", fmt.Sprint(cfg.RateLimit),
		"-c", fmt.Sprint(cfg.Threads),
		"-sa",    // skip host-discovery (hosts already known-alive)
		"-Pn",
	}, 20*time.Minute)

	if err != nil {
		logger.Warning("SCANNING", fmt.Sprintf("naabu: %v", err))
	}

	// naabu output: "host:port"
	result := make(map[string][]string)
	for _, line := range lines {
		parts := strings.SplitN(line, ":", 2)
		if len(parts) == 2 {
			result[parts[0]] = append(result[parts[0]], parts[1])
		}
	}

	if err := w.WriteLines("scanning", "open_ports.txt", lines); err != nil {
		logger.Warning("SCANNING", fmt.Sprintf("write open_ports: %v", err))
	}

	logger.Success("SCANNING", fmt.Sprintf("naabu: %d open ports across %d hosts",
		len(lines), len(result)))
	return result
}

// ─────────────────────────────────────────
//  nmap
// ─────────────────────────────────────────

// nonTrivialPorts triggers a deep nmap scan when any of these are open.
var nonTrivialPorts = map[string]bool{
	"21": true, "22": true, "25": true, "587": true,
	"6379": true, "9200": true, "27017": true, "5432": true, "3306": true,
}

func runNmapTargeted(ctx context.Context, cfg *config.Config, w *output.Writer, openPorts map[string][]string) {
	for host, ports := range openPorts {
		needsDeep := false
		for _, p := range ports {
			if nonTrivialPorts[p] {
				needsDeep = true
				break
			}
		}
		if !needsDeep {
			continue
		}

		outFile := w.FilePath("scanning", "nmap_"+sanitize(host)+".txt")
		_, err := runner.Run(ctx, "SCANNING", cfg.Tools.Nmap, []string{
			"-sV", "-sC",
			"-p", strings.Join(ports, ","),
			"--open", "-T4",
			"-oN", outFile,
			host,
		}, 10*time.Minute)
		if err != nil {
			logger.Warning("SCANNING", fmt.Sprintf("nmap %s: %v", host, err))
			continue
		}
		logger.Success("SCANNING", fmt.Sprintf("nmap: %s → %s", host, outFile))
	}
}

// ─────────────────────────────────────────
//  ffuf
// ─────────────────────────────────────────

func runFFUF(ctx context.Context, cfg *config.Config, w *output.Writer, hosts []string) []string {
	var (
		mu          sync.Mutex
		discovered  []string
		sem         = make(chan struct{}, 5) // max 5 ffuf instances at once
		wg          sync.WaitGroup
	)

	for _, host := range hosts {
		wg.Add(1)
		go func(h string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			outFile := w.FilePath("scanning", "ffuf_"+sanitize(h)+".json")
			lines, err := runner.Run(ctx, "SCANNING", cfg.Tools.Ffuf, []string{
				"-u", h + "/FUZZ",
				"-w", cfg.Wordlists.Directories,
				"-mc", "200,201,204,301,302,307,401,403,405,500",
				"-ac",      // auto-calibrate
				"-t", "50",
				"-rate", "100",
				"-s",       // ffuf v2: silent mode (was -silent in v1)
				"-o", outFile,
				"-of", "json",
			}, 15*time.Minute)
			if err != nil {
				logger.Debug("SCANNING", fmt.Sprintf("ffuf %s: %v", h, err))
				return
			}
			mu.Lock()
			discovered = append(discovered, lines...)
			mu.Unlock()
		}(host)
	}
	wg.Wait()

	if err := w.WriteLines("scanning", "directories.txt", discovered); err != nil {
		logger.Warning("SCANNING", fmt.Sprintf("write directories: %v", err))
	}
	logger.Success("SCANNING", fmt.Sprintf("ffuf: %d paths discovered", len(discovered)))
	return discovered
}

// ─────────────────────────────────────────
//  wpscan
// ─────────────────────────────────────────

func runWPScan(ctx context.Context, cfg *config.Config, w *output.Writer, host string) {
	logger.Info("SCANNING", fmt.Sprintf("WordPress on %s — running wpscan", host))

	lines, err := runner.Run(ctx, "SCANNING", "wpscan", []string{
		"--url", host,
		"--enumerate", "p,t,u,cb,dbe",  // plugins, themes, users, config backups, db exports
		"--plugins-detection", "aggressive",
		"--random-user-agent",
		"--no-banner",
	}, 20*time.Minute)
	if err != nil {
		logger.Warning("SCANNING", fmt.Sprintf("wpscan %s: %v", host, err))
	}

	outFile := "wpscan_" + sanitize(host) + ".txt"
	if writeErr := w.WriteLines("scanning", outFile, lines); writeErr != nil {
		logger.Warning("SCANNING", fmt.Sprintf("write wpscan: %v", writeErr))
	}
}

// ─────────────────────────────────────────
//  API discovery
// ─────────────────────────────────────────

// runAPIDiscovery looks for common API spec files (swagger, openapi).
func runAPIDiscovery(ctx context.Context, cfg *config.Config, w *output.Writer, discovery *DiscoveryResult) []string {
	var apiHosts []string
	for _, stack := range discovery.TechStacks {
		if stack.HasAPI {
			apiHosts = append(apiHosts, stack.Host)
		}
	}
	if len(apiHosts) == 0 {
		return nil
	}

	apiPaths := []string{
		"/swagger.json", "/swagger.yaml",
		"/openapi.json", "/openapi.yaml",
		"/api/swagger.json", "/api/v1/swagger.json",
		"/v2/api-docs", "/api-docs",
	}

	var (
		found []string
		mu    sync.Mutex
		wg    sync.WaitGroup
	)

	for _, host := range apiHosts {
		for _, path := range apiPaths {
			wg.Add(1)
			go func(h, p string) {
				defer wg.Done()
				lines, err := runner.Run(ctx, "SCANNING", "curl", []string{
					"-s", "-o", "/dev/null",
					"-w", "%{http_code} " + h + p,
					"-m", "10",
					h + p,
				}, 15*time.Second)
				if err != nil || len(lines) == 0 {
					return
				}
				if strings.HasPrefix(lines[0], "200") {
					mu.Lock()
					found = append(found, h+p)
					mu.Unlock()
					logger.Success("SCANNING", fmt.Sprintf("API spec: %s%s", h, p))
				}
			}(host, path)
		}
	}
	wg.Wait()

	w.WriteLines("scanning", "api_endpoints.txt", found)
	return found
}

// ─────────────────────────────────────────
//  Utilities
// ─────────────────────────────────────────

// sanitize converts a URL/host into a safe filename fragment.
func sanitize(s string) string {
	r := strings.NewReplacer(
		"https://", "", "http://", "",
		"/", "_", ":", "_", ".", "_",
	)
	return r.Replace(s)
}

// intMin returns the smaller of two ints.
func intMin(a, b int) int {
	if a < b {
		return a
	}
	return b
}
