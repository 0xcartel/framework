package config

import (
	"fmt"
	"os"

	"gopkg.in/yaml.v3"
)

// Config holds all settings loaded from config.yaml
type Config struct {
	OutputDir  string `yaml:"output_dir"`
	Threads    int    `yaml:"threads"`
	RateLimit  int    `yaml:"rate_limit"`
	Timeout    int    `yaml:"timeout"`
	Verbose    bool   `yaml:"verbose"`

	Tools struct {
		Subfinder    string `yaml:"subfinder"`
		Amass        string `yaml:"amass"`
		Assetfinder  string `yaml:"assetfinder"`
		Httpx        string `yaml:"httpx"`
		Dnsx         string `yaml:"dnsx"`
		Gau          string `yaml:"gau"`
		Waybackurls  string `yaml:"waybackurls"`
		Katana       string `yaml:"katana"`
		Hakrawler    string `yaml:"hakrawler"`
		Naabu        string `yaml:"naabu"`
		Nmap         string `yaml:"nmap"`
		Ffuf         string `yaml:"ffuf"`
		Nuclei       string `yaml:"nuclei"`
		Dalfox       string `yaml:"dalfox"`
		Sqlmap       string `yaml:"sqlmap"`
		Corsy        string `yaml:"corsy"`
		Secretfinder string `yaml:"secretfinder"`
		Interactsh   string `yaml:"interactsh"`
		Notify       string `yaml:"notify"`
		Anew         string `yaml:"anew"`
		Gf           string `yaml:"gf"`
		Linkfinder   string `yaml:"linkfinder"`
	} `yaml:"tools"`

	APIs struct {
		Shodan         string `yaml:"shodan"`
		Chaos          string `yaml:"chaos"`
		TelegramToken  string `yaml:"telegram_token"`
		TelegramChat   string `yaml:"telegram_chat"`
		DiscordWebhook string `yaml:"discord_webhook"`
	} `yaml:"apis"`

	Phases struct {
		Recon      bool `yaml:"recon"`
		Discovery  bool `yaml:"discovery"`
		Scanning   bool `yaml:"scanning"`
		Vulns      bool `yaml:"vulns"`
		Validation bool `yaml:"validation"`
		Reporting  bool `yaml:"reporting"`
	} `yaml:"phases"`

	NucleiSeverity string `yaml:"nuclei_severity"`

	Wordlists struct {
		Directories string `yaml:"directories"`
		Parameters  string `yaml:"parameters"`
	} `yaml:"wordlists"`
}

// Load reads config.yaml and returns a Config struct
func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("cannot read config file %q: %w", path, err)
	}

	var cfg Config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, fmt.Errorf("invalid YAML in config file: %w", err)
	}

	if err := cfg.validate(); err != nil {
		return nil, fmt.Errorf("config validation failed: %w", err)
	}

	cfg.setDefaults()
	return &cfg, nil
}

// validate checks required fields
func (c *Config) validate() error {
	if c.Threads <= 0 {
		return fmt.Errorf("threads must be > 0")
	}
	if c.Timeout <= 0 {
		return fmt.Errorf("timeout must be > 0")
	}
	if c.OutputDir == "" {
		return fmt.Errorf("output_dir cannot be empty")
	}
	return nil
}

// setDefaults fills zero-value fields with sensible defaults
func (c *Config) setDefaults() {
	if c.Threads == 0 {
		c.Threads = 50
	}
	if c.Timeout == 0 {
		c.Timeout = 30
	}
	if c.RateLimit == 0 {
		c.RateLimit = 150
	}
	if c.NucleiSeverity == "" {
		c.NucleiSeverity = "critical,high"
	}

	// default tool names (assume in $PATH)
	tools := &c.Tools
	if tools.Subfinder == "" {
		tools.Subfinder = "subfinder"
	}
	if tools.Amass == "" {
		tools.Amass = "amass"
	}
	if tools.Httpx == "" {
		tools.Httpx = "httpx"
	}
	if tools.Nuclei == "" {
		tools.Nuclei = "nuclei"
	}
	if tools.Nmap == "" {
		tools.Nmap = "nmap"
	}
}
