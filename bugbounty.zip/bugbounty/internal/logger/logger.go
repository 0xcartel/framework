package logger

import (
	"fmt"
	"os"
	"sync"
	"time"
)

// ANSI codes
const (
	reset  = "\033[0m"
	bold   = "\033[1m"
	red    = "\033[31m"
	green  = "\033[32m"
	yellow = "\033[33m"
	blue   = "\033[34m"
	purple = "\033[35m"
	cyan   = "\033[36m"
	white  = "\033[37m"
	gray   = "\033[90m"
)

var (
	verbose bool
	mu      sync.Mutex // serialize writes so lines don't interleave
)

// SetVerbose enables or disables debug messages.
func SetVerbose(v bool) { verbose = v }

// ---- public logging functions ----

func Info(phase, msg string)     { log("INF", cyan, phase, msg) }
func Success(phase, msg string)  { log("SUC", green, phase, msg) }
func Warning(phase, msg string)  { log("WRN", yellow, phase, msg) }
func Error(phase, msg string)    { log("ERR", red, phase, msg) }
func Critical(phase, msg string) { log("CRT", bold+red, phase, msg) }
func Debug(phase, msg string) {
	if verbose {
		log("DBG", gray, phase, msg)
	}
}

// log is the single write path — mutex-protected.
func log(prefix, color, phase, msg string) {
	ts := time.Now().Format("15:04:05")

	phaseStr := ""
	if phase != "" {
		phaseStr = purple + "[" + phase + "]" + reset + " "
	}

	mu.Lock()
	fmt.Fprintf(os.Stderr, "%s%s[%s]%s %s%s%s\n",
		color, bold, ts, reset,
		phaseStr,
		color, msg+reset,
	)
	mu.Unlock()
}

// Banner prints the ASCII art header.
func Banner() {
	fmt.Print(green + bold + `
  ██████╗ ██╗   ██╗ ██████╗     ██████╗  ██████╗ ██╗   ██╗███╗   ██╗████████╗██╗   ██╗
  ██╔══██╗██║   ██║██╔════╝     ██╔══██╗██╔═══██╗██║   ██║████╗  ██║╚══██╔══╝╚██╗ ██╔╝
  ██████╔╝██║   ██║██║  ███╗    ██████╔╝██║   ██║██║   ██║██╔██╗ ██║   ██║    ╚████╔╝
  ██╔══██╗██║   ██║██║   ██║    ██╔══██╗██║   ██║██║   ██║██║╚██╗██║   ██║     ╚██╔╝
  ██████╔╝╚██████╔╝╚██████╔╝    ██████╔╝╚██████╔╝╚██████╔╝██║ ╚████║   ██║      ██║
  ╚═════╝  ╚═════╝  ╚═════╝     ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝   ╚═╝      ╚═╝
` + reset)
	fmt.Println(cyan + "  Bug Bounty Automation Framework v1.0  |  github.com/bugbounty" + reset)
	fmt.Println()
}
