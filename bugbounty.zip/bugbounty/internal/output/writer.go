package output

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// ─────────────────────────────────────────
//  Finding
// ─────────────────────────────────────────

// Finding is one confirmed vulnerability or interesting observation.
type Finding struct {
	ID          string    `json:"id"`
	Tool        string    `json:"tool"`
	Phase       string    `json:"phase"`
	Host        string    `json:"host"`
	URL         string    `json:"url"`
	Type        string    `json:"type"`
	Severity    string    `json:"severity"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	Evidence    string    `json:"evidence"`
	CVSS        float64   `json:"cvss_score"`
	PoC         string    `json:"poc"`
	Timestamp   time.Time `json:"timestamp"`
	Tags        []string  `json:"tags"`
}

// ─────────────────────────────────────────
//  Writer
// ─────────────────────────────────────────

// Writer handles all file output for one scan session.
type Writer struct {
	baseDir  string
	mu       sync.Mutex
	findings []Finding
	seen     map[string]struct{} // dedup key → exists
}

// New creates the output directory tree and returns a Writer.
// The tree is:  baseDir/{recon,discovery,scanning,vulns,validation,reports}
func New(baseDir string) (*Writer, error) {
	subdirs := []string{
		"recon", "discovery", "scanning",
		"vulns", "validation", "reports",
	}
	for _, d := range subdirs {
		path := filepath.Join(baseDir, d)
		if err := os.MkdirAll(path, 0o755); err != nil {
			return nil, fmt.Errorf("mkdir %q: %w", path, err)
		}
	}
	return &Writer{
		baseDir: baseDir,
		seen:    make(map[string]struct{}),
	}, nil
}

// ─────────────────────────────────────────
//  File helpers
// ─────────────────────────────────────────

// FilePath returns the absolute path for subdir/filename.
func (w *Writer) FilePath(subdir, filename string) string {
	return filepath.Join(w.baseDir, subdir, filename)
}

// WriteLines appends lines to subdir/filename, skipping duplicates and blanks.
// It is safe to call from multiple goroutines.
func (w *Writer) WriteLines(subdir, filename string, lines []string) error {
	if len(lines) == 0 {
		return nil
	}

	path := w.FilePath(subdir, filename)

	// build existing-lines set for dedup
	existing := w.readSet(path)

	w.mu.Lock()
	defer w.mu.Unlock()

	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return fmt.Errorf("open %q: %w", path, err)
	}
	defer f.Close()

	bw := bufio.NewWriterSize(f, 64*1024)
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if _, dup := existing[line]; dup {
			continue
		}
		existing[line] = struct{}{}
		fmt.Fprintln(bw, line)
	}
	if err := bw.Flush(); err != nil {
		return fmt.Errorf("flush %q: %w", path, err)
	}
	return nil
}

// ReadLines returns all non-blank lines from subdir/filename.
// Returns nil, nil if the file does not exist yet.
func (w *Writer) ReadLines(subdir, filename string) ([]string, error) {
	path := w.FilePath(subdir, filename)
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, fmt.Errorf("read %q: %w", path, err)
	}
	defer f.Close()

	var lines []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		if line := strings.TrimSpace(sc.Text()); line != "" {
			lines = append(lines, line)
		}
	}
	return lines, sc.Err()
}

// readSet reads all lines from a file into a map (for O(1) lookups).
// Returns an empty map if the file doesn't exist.
func (w *Writer) readSet(path string) map[string]struct{} {
	set := make(map[string]struct{})
	f, err := os.Open(path)
	if err != nil {
		return set
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		if line := strings.TrimSpace(sc.Text()); line != "" {
			set[line] = struct{}{}
		}
	}
	return set
}

// ─────────────────────────────────────────
//  Findings store
// ─────────────────────────────────────────

// AddFinding records a finding, deduplicating on (Host, Type, URL).
// Thread-safe.
func (w *Writer) AddFinding(f Finding) {
	key := fmt.Sprintf("%s|%s|%s", f.Host, f.Type, f.URL)

	w.mu.Lock()
	defer w.mu.Unlock()

	if _, dup := w.seen[key]; dup {
		return
	}
	w.seen[key] = struct{}{}

	f.ID = fmt.Sprintf("FIND-%04d", len(w.findings)+1)
	f.Timestamp = time.Now().UTC()
	w.findings = append(w.findings, f)
}

// Findings returns a snapshot of all findings collected so far.
func (w *Writer) Findings() []Finding {
	w.mu.Lock()
	defer w.mu.Unlock()
	out := make([]Finding, len(w.findings))
	copy(out, w.findings)
	return out
}

// SaveFindings serialises all findings to reports/findings.json.
func (w *Writer) SaveFindings() error {
	w.mu.Lock()
	defer w.mu.Unlock()

	path := w.FilePath("reports", "findings.json")
	f, err := os.Create(path)
	if err != nil {
		return fmt.Errorf("create %q: %w", path, err)
	}
	defer f.Close()

	enc := json.NewEncoder(f)
	enc.SetIndent("", "  ")
	if err := enc.Encode(w.findings); err != nil {
		return fmt.Errorf("encode findings: %w", err)
	}
	return nil
}

// ─────────────────────────────────────────
//  Stats
// ─────────────────────────────────────────

// Stats summarises findings by severity.
type Stats struct {
	Total    int
	Critical int
	High     int
	Medium   int
	Low      int
	Info     int
}

// Stats returns a severity breakdown of all recorded findings.
func (w *Writer) Stats() Stats {
	w.mu.Lock()
	defer w.mu.Unlock()

	s := Stats{Total: len(w.findings)}
	for _, f := range w.findings {
		switch strings.ToLower(f.Severity) {
		case "critical":
			s.Critical++
		case "high":
			s.High++
		case "medium":
			s.Medium++
		case "low":
			s.Low++
		default:
			s.Info++
		}
	}
	return s
}
