package notify

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/bugbounty/internal/output"
)

// telegramMaxLen is Telegram's hard character limit per message.
const telegramMaxLen = 4096

// ─────────────────────────────────────────
//  Notifier
// ─────────────────────────────────────────

// Notifier sends alerts to Telegram and/or Discord.
// Both channels are optional; if a token/webhook is empty that channel is skipped.
type Notifier struct {
	telegramToken string
	telegramChat  string
	discordWH     string
	client        *http.Client
}

// New returns a configured Notifier.
func New(telegramToken, telegramChat, discordWH string) *Notifier {
	return &Notifier{
		telegramToken: telegramToken,
		telegramChat:  telegramChat,
		discordWH:     discordWH,
		client:        &http.Client{Timeout: 15 * time.Second},
	}
}

// ─────────────────────────────────────────
//  Public API
// ─────────────────────────────────────────

// Alert sends one finding immediately.
// Only Critical and High fire an alert to avoid chat spam.
func (n *Notifier) Alert(f output.Finding) {
	sev := strings.ToLower(f.Severity)
	if sev != "critical" && sev != "high" {
		return
	}
	n.sendAll(formatFinding(f), colorFor(sev))
}

// SendRaw sends any arbitrary message directly to all channels.
// Used for the combined multi-target summary.
func (n *Notifier) SendRaw(msg string, color int) {
	n.sendAll(msg, color)
}

// PhaseComplete sends a short phase-completion notice.
func (n *Notifier) PhaseComplete(phase string, count int) {
	msg := fmt.Sprintf("✅ *Phase %s completed* — %d results", phase, count)
	n.sendAll(msg, 0x00CC44)
}

// ScanComplete sends a FULL final report:
//   - Header with counts per severity
//   - Every finding listed (title + URL + CVSS), grouped by severity
//   - Automatically splits into multiple messages when the text
//     exceeds Telegram's 4096-character limit
func (n *Notifier) ScanComplete(target string, stats output.Stats, findings []output.Finding) {
	// ── 1. Header ──────────────────────────────────────────────────
	header := fmt.Sprintf(
		"🏁 *Scan complete: %s*\n"+
			"🕐 %s\n\n"+
			"🔴 Critical : `%d`\n"+
			"🟠 High     : `%d`\n"+
			"🟡 Medium   : `%d`\n"+
			"🟢 Low      : `%d`\n"+
			"🔵 Info     : `%d`\n"+
			"📊 Total    : `%d`",
		target,
		time.Now().Format("2006-01-02 15:04:05"),
		stats.Critical, stats.High, stats.Medium, stats.Low, stats.Info, stats.Total,
	)
	n.sendAll(header, 0x0099FF)

	if len(findings) == 0 {
		return
	}

	// ── 2. Group findings by severity ─────────────────────────────
	order := []string{"critical", "high", "medium", "low", "info"}
	groups := make(map[string][]output.Finding)
	for _, f := range findings {
		sev := strings.ToLower(f.Severity)
		groups[sev] = append(groups[sev], f)
	}

	// ── 3. Build one block per severity group ──────────────────────
	for _, sev := range order {
		items, ok := groups[sev]
		if !ok || len(items) == 0 {
			continue
		}

		// section header
		sectionHeader := fmt.Sprintf(
			"%s *%s Findings (%d)*\n%s",
			emojiFor(sev), strings.ToUpper(sev), len(items),
			strings.Repeat("─", 30),
		)

		// build lines for every finding in this severity
		var lines []string
		for i, f := range items {
			line := fmt.Sprintf(
				"*%d. %s*\n"+
					"   🔗 `%s`\n"+
					"   🛠 %s  |  📊 CVSS `%.1f`  |  🔑 `%s`",
				i+1, escMD(f.Title),
				f.URL,
				f.Tool, f.CVSS, f.Type,
			)
			lines = append(lines, line)
		}

		// split into chunks that fit Telegram's limit
		chunks := splitIntoChunks(sectionHeader, lines, telegramMaxLen)
		for ci, chunk := range chunks {
			suffix := ""
			if len(chunks) > 1 {
				suffix = fmt.Sprintf("\n\n_(part %d/%d)_", ci+1, len(chunks))
			}
			n.sendAll(chunk+suffix, colorFor(sev))
		}
	}
}

// ─────────────────────────────────────────
//  Formatting helpers
// ─────────────────────────────────────────

// formatFinding builds the detailed alert message for a single finding.
func formatFinding(f output.Finding) string {
	poc := ""
	if f.PoC != "" {
		poc = fmt.Sprintf("\n\n🧪 *PoC:*\n`%s`", f.PoC)
	}
	desc := ""
	if f.Description != "" {
		desc = fmt.Sprintf("\n\n📋 %s", f.Description)
	}
	return fmt.Sprintf(
		"%s *[%s] %s*\n\n"+
			"🎯 Host : `%s`\n"+
			"🔗 URL  : `%s`\n"+
			"🛠 Tool : `%s`\n"+
			"🔑 Type : `%s`\n"+
			"📊 CVSS : `%.1f`\n"+
			"🕐 Time : `%s`"+
			"%s%s",
		emojiFor(f.Severity),
		strings.ToUpper(f.Severity),
		f.Title,
		f.Host,
		f.URL,
		f.Tool,
		f.Type,
		f.CVSS,
		f.Timestamp.Format("2006-01-02 15:04:05"),
		desc,
		poc,
	)
}

// splitIntoChunks returns a slice of messages where each message starts
// with the sectionHeader and is padded with as many finding lines as
// fit within maxLen characters.
func splitIntoChunks(header string, lines []string, maxLen int) []string {
	var chunks []string
	current := header

	for _, line := range lines {
		candidate := current + "\n\n" + line
		if len(candidate) > maxLen {
			// current chunk is full — flush it
			if current != header {
				chunks = append(chunks, current)
			}
			// start a new chunk with just this line
			current = header + "\n\n" + line
		} else {
			current = candidate
		}
	}
	if current != header {
		chunks = append(chunks, current)
	}
	return chunks
}

// escMD escapes Markdown special characters in plain text.
func escMD(s string) string {
	replacer := strings.NewReplacer(
		"_", "\\_", "*", "\\*", "[", "\\[", "`", "\\`",
	)
	return replacer.Replace(s)
}

// ─────────────────────────────────────────
//  Transport
// ─────────────────────────────────────────

// sendAll delivers msg to every configured channel.
func (n *Notifier) sendAll(msg string, color int) {
	if n.telegramToken != "" && n.telegramChat != "" {
		if err := n.telegram(msg); err != nil {
			fmt.Printf("[notify] telegram: %v\n", err)
		}
	}
	if n.discordWH != "" {
		if err := n.discord(msg, color); err != nil {
			fmt.Printf("[notify] discord: %v\n", err)
		}
	}
}

// telegram posts one message via the Bot API.
func (n *Notifier) telegram(text string) error {
	// hard-truncate as a last-resort safety net
	if len(text) > telegramMaxLen {
		text = text[:telegramMaxLen-3] + "..."
	}

	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", n.telegramToken)
	body, err := json.Marshal(map[string]interface{}{
		"chat_id":    n.telegramChat,
		"text":       text,
		"parse_mode": "Markdown",
	})
	if err != nil {
		return fmt.Errorf("marshal: %w", err)
	}

	resp, err := n.client.Post(url, "application/json", bytes.NewReader(body))
	if err != nil {
		return fmt.Errorf("post: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("telegram returned HTTP %d", resp.StatusCode)
	}
	return nil
}

// discord posts an embed via a webhook URL.
func (n *Notifier) discord(msg string, color int) error {
	type embed struct {
		Title       string `json:"title"`
		Description string `json:"description"`
		Color       int    `json:"color"`
		Timestamp   string `json:"timestamp"`
	}
	type payload struct {
		Username string  `json:"username"`
		Embeds   []embed `json:"embeds"`
	}

	p := payload{
		Username: "BugBounty Bot 🤖",
		Embeds: []embed{{
			Title:       "🔍 Bug Bounty Update",
			Description: msg,
			Color:       color,
			Timestamp:   time.Now().UTC().Format(time.RFC3339),
		}},
	}

	body, err := json.Marshal(p)
	if err != nil {
		return fmt.Errorf("marshal: %w", err)
	}

	resp, err := n.client.Post(n.discordWH, "application/json", bytes.NewReader(body))
	if err != nil {
		return fmt.Errorf("post: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		return fmt.Errorf("discord returned HTTP %d", resp.StatusCode)
	}
	return nil
}

// ─────────────────────────────────────────
//  Helpers
// ─────────────────────────────────────────

func emojiFor(sev string) string {
	switch strings.ToLower(sev) {
	case "critical":
		return "🔴"
	case "high":
		return "🟠"
	case "medium":
		return "🟡"
	case "low":
		return "🟢"
	default:
		return "🔵"
	}
}

func colorFor(sev string) int {
	switch strings.ToLower(sev) {
	case "critical":
		return 0xFF2D55
	case "high":
		return 0xFF9F0A
	case "medium":
		return 0xFFD60A
	case "low":
		return 0x30D158
	default:
		return 0x0A84FF
	}
}
