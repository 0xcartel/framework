#!/usr/bin/env python3
"""
Bug Bounty Report Generator
Reads findings.json and produces a self-contained HTML report.

Usage:
    python3 reporter/report.py \
        --findings output/example.com_20240101_120000/reports/findings.json \
        --target   example.com \
        --output   output/report.html
"""

import argparse
import json
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

# ─────────────────────────────────────────
#  Constants
# ─────────────────────────────────────────

SEVERITY_ORDER  = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
SEVERITY_COLOR  = {
    "critical": "#FF2D55",
    "high":     "#FF9F0A",
    "medium":   "#FFD60A",
    "low":      "#30D158",
    "info":     "#0A84FF",
}
SEVERITY_BG     = {
    "critical": "rgba(255,45,85,.12)",
    "high":     "rgba(255,159,10,.10)",
    "medium":   "rgba(255,214,10,.10)",
    "low":      "rgba(48,209,88,.10)",
    "info":     "rgba(10,132,255,.10)",
}
SEVERITY_EMOJI  = {
    "critical": "🔴",
    "high":     "🟠",
    "medium":   "🟡",
    "low":      "🟢",
    "info":     "🔵",
}


# ─────────────────────────────────────────
#  Data loading
# ─────────────────────────────────────────

def load_findings(path: str) -> list[dict]:
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, list) else []
    except FileNotFoundError:
        print(f"[!] File not found: {path}", file=sys.stderr)
        return []
    except json.JSONDecodeError as exc:
        print(f"[!] JSON parse error in {path}: {exc}", file=sys.stderr)
        return []


def group_by_severity(findings: list[dict]) -> dict[str, list[dict]]:
    groups: dict[str, list[dict]] = defaultdict(list)
    for f in findings:
        sev = (f.get("severity") or "info").lower()
        groups[sev].append(f)
    return dict(sorted(groups.items(), key=lambda kv: SEVERITY_ORDER.get(kv[0], 99)))


# ─────────────────────────────────────────
#  HTML helpers
# ─────────────────────────────────────────

def esc(text: str) -> str:
    """Minimal HTML-escape."""
    return (text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def badge(sev: str) -> str:
    col = SEVERITY_COLOR.get(sev, "#888")
    em  = SEVERITY_EMOJI.get(sev, "⚪")
    return (
        f'<span class="badge" style="background:{col};color:#000">'
        f'{em} {esc(sev.upper())}</span>'
    )


def tag_pills(tags: list) -> str:
    if not tags:
        return ""
    pills = "".join(f'<span class="tag">{esc(t)}</span>' for t in tags)
    return f'<div class="tags">{pills}</div>'


def code_block(text: str, label: str = "") -> str:
    if not text:
        return ""
    lbl = f'<div class="code-label">{esc(label)}</div>' if label else ""
    return f'{lbl}<div class="code"><code>{esc(text)}</code></div>'


# ─────────────────────────────────────────
#  Card builder
# ─────────────────────────────────────────

def finding_card(f: dict) -> str:
    sev      = (f.get("severity") or "info").lower()
    col      = SEVERITY_COLOR.get(sev, "#888")
    bg       = SEVERITY_BG.get(sev, "rgba(128,128,128,.1)")
    ts_raw   = f.get("timestamp", "")
    ts       = ts_raw[:19].replace("T", " ") if ts_raw else "—"
    cvss     = f.get("cvss_score") or 0.0
    tool     = f.get("tool") or ""
    ftype    = f.get("type") or ""
    host     = f.get("host") or ""
    url      = f.get("url") or ""
    title    = f.get("title") or "Unknown Finding"
    desc     = f.get("description") or ""
    evidence = f.get("evidence") or ""
    poc      = f.get("poc") or ""
    find_id  = f.get("id") or ""

    return f"""
<div class="card" id="{esc(find_id)}" style="border-left:3px solid {col};background:{bg}">
  <div class="card-head">
    <div class="card-left">
      {badge(sev)}
      <span class="card-title">{esc(title)}</span>
    </div>
    <div class="card-meta">
      <span class="meta-chip">{esc(tool)}</span>
      <span class="meta-chip" style="color:{col}">CVSS {cvss:.1f}</span>
      <span class="meta-chip muted">{esc(ts)}</span>
      <span class="meta-chip muted">{esc(find_id)}</span>
    </div>
  </div>
  <div class="card-body">
    <div class="row"><span class="label">Type</span><code>{esc(ftype)}</code></div>
    <div class="row"><span class="label">Host</span><code>{esc(host)}</code></div>
    <div class="row"><span class="label">URL</span><code class="wrap">{esc(url)}</code></div>
    {"" if not desc     else f'<div class="row"><span class="label">Description</span><span>{esc(desc)}</span></div>'}
    {code_block(evidence, "Evidence")}
    {code_block(poc,      "Proof of Concept")}
    {tag_pills(f.get("tags") or [])}
  </div>
</div>"""


# ─────────────────────────────────────────
#  Full HTML
# ─────────────────────────────────────────

def build_html(findings: list[dict], target: str) -> str:
    groups = group_by_severity(findings)
    total  = len(findings)
    stats  = {sev: len(items) for sev, items in groups.items()}
    now    = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    # stat cards
    stat_cards = ""
    for sev in ["critical", "high", "medium", "low", "info"]:
        cnt = stats.get(sev, 0)
        col = SEVERITY_COLOR.get(sev, "#888")
        em  = SEVERITY_EMOJI.get(sev, "⚪")
        stat_cards += f"""
<div class="stat-card">
  <span class="stat-num" style="color:{col}">{cnt}</span>
  <span class="stat-label">{em} {sev.capitalize()}</span>
</div>"""
    stat_cards += f"""
<div class="stat-card">
  <span class="stat-num" style="color:#00ff88">{total}</span>
  <span class="stat-label">📊 Total</span>
</div>"""

    # finding sections
    sections = ""
    for sev in ["critical", "high", "medium", "low", "info"]:
        items = groups.get(sev, [])
        if not items:
            continue
        col = SEVERITY_COLOR.get(sev, "#888")
        em  = SEVERITY_EMOJI.get(sev, "⚪")
        cards_html = "\n".join(finding_card(f) for f in items)
        sections += f"""
<section>
  <h2 class="sev-heading" style="border-left:4px solid {col}">
    {em} {sev.upper()} <span class="count">({len(items)})</span>
  </h2>
  {cards_html}
</section>"""

    if not sections:
        sections = '<div class="empty">🎉 No findings to report.</div>'

    # navigation links
    nav_links = " ".join(
        f'<a href="#{sev}" class="nav-link" style="color:{SEVERITY_COLOR.get(sev,"#888")}">'
        f'{SEVERITY_EMOJI.get(sev,"")} {sev.capitalize()} ({stats.get(sev,0)})</a>'
        for sev in ["critical","high","medium","low","info"]
        if stats.get(sev, 0) > 0
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Bug Bounty Report — {esc(target)}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Inter:wght@300;400;600;700&display=swap');
:root{{
  --bg:#0a0d14;--surface:#111520;--border:#1e2535;
  --text:#c8d0e0;--muted:#4a5568;--bright:#fff;--accent:#00ff88;
  --radius:8px;
}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;line-height:1.6;font-size:14px}}
body::before{{content:'';position:fixed;inset:0;pointer-events:none;z-index:0;
  background-image:linear-gradient(rgba(0,255,136,.025) 1px,transparent 1px),
  linear-gradient(90deg,rgba(0,255,136,.025) 1px,transparent 1px);
  background-size:40px 40px}}

.wrap{{position:relative;z-index:1;max-width:1100px;margin:0 auto;padding:40px 20px 100px}}

/* ── Header ── */
header{{text-align:center;margin-bottom:48px}}
.logo{{display:inline-block;font-family:'JetBrains Mono',monospace;font-size:10px;
  letter-spacing:3px;color:var(--accent);border:1px solid var(--accent);
  padding:4px 14px;border-radius:2px;margin-bottom:18px}}
header h1{{font-size:clamp(22px,4vw,42px);font-weight:700;color:var(--bright)}}
header h1 span{{color:var(--accent)}}
.meta{{font-size:12px;color:var(--muted);margin-top:8px}}

/* ── Nav ── */
.nav{{display:flex;flex-wrap:wrap;gap:12px;justify-content:center;margin-bottom:40px}}
.nav-link{{text-decoration:none;font-size:13px;font-family:'JetBrains Mono',monospace;
  border:1px solid currentColor;padding:4px 12px;border-radius:4px;
  opacity:.7;transition:opacity .2s}}
.nav-link:hover{{opacity:1}}

/* ── Stats ── */
.stats{{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px;margin-bottom:48px}}
.stat-card{{background:var(--surface);border:1px solid var(--border);
  border-radius:var(--radius);padding:20px;text-align:center}}
.stat-num{{display:block;font-family:'JetBrains Mono',monospace;font-size:34px;font-weight:700}}
.stat-label{{display:block;font-size:11px;color:var(--muted);margin-top:4px;text-transform:uppercase;letter-spacing:1px}}

/* ── Section ── */
.sev-heading{{font-size:17px;font-weight:600;color:var(--bright);
  padding:10px 16px;margin-bottom:16px;margin-top:8px;
  background:rgba(255,255,255,.02);border-radius:4px}}
.sev-heading .count{{font-weight:400;color:var(--muted)}}

/* ── Cards ── */
.card{{background:var(--surface);border:1px solid var(--border);
  border-radius:var(--radius);margin-bottom:16px;overflow:hidden}}
.card-head{{display:flex;justify-content:space-between;align-items:flex-start;
  flex-wrap:wrap;gap:10px;padding:16px 20px;border-bottom:1px solid var(--border);
  background:rgba(255,255,255,.02)}}
.card-left{{display:flex;align-items:center;gap:10px;flex-wrap:wrap}}
.card-title{{font-size:15px;font-weight:600;color:var(--bright)}}
.card-meta{{display:flex;gap:8px;flex-wrap:wrap;align-items:center}}
.meta-chip{{background:rgba(255,255,255,.05);border:1px solid var(--border);
  padding:2px 8px;border-radius:3px;font-size:11px;font-family:'JetBrains Mono',monospace;white-space:nowrap}}
.meta-chip.muted{{color:var(--muted)}}
.badge{{display:inline-block;padding:3px 10px;border-radius:4px;
  font-size:10px;font-weight:700;font-family:'JetBrains Mono',monospace;letter-spacing:1px}}
.card-body{{padding:18px 20px}}
.row{{display:flex;gap:12px;margin-bottom:10px;align-items:flex-start;font-size:13px}}
.label{{min-width:100px;color:var(--muted);font-weight:600;padding-top:1px;flex-shrink:0}}
code{{background:rgba(255,255,255,.06);padding:2px 7px;border-radius:4px;
  font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--accent)}}
code.wrap{{word-break:break-all}}
.code{{background:#0d1117;border:1px solid var(--border);border-radius:6px;
  padding:14px;margin-top:12px;overflow-x:auto}}
.code code{{background:none;padding:0;font-size:12px;color:#58a6ff;word-break:break-all;white-space:pre-wrap}}
.code-label{{font-size:11px;color:var(--muted);margin-top:14px;margin-bottom:4px;
  text-transform:uppercase;letter-spacing:1px;font-family:'JetBrains Mono',monospace}}
.tags{{margin-top:12px;display:flex;flex-wrap:wrap;gap:6px}}
.tag{{background:rgba(10,132,255,.1);border:1px solid rgba(10,132,255,.3);
  padding:2px 8px;border-radius:3px;font-size:11px;font-family:'JetBrains Mono',monospace}}
.empty{{text-align:center;color:var(--muted);padding:60px 20px;
  border:1px dashed var(--border);border-radius:var(--radius)}}

/* ── Footer ── */
footer{{text-align:center;margin-top:60px;font-size:12px;color:var(--muted)}}

@media(max-width:600px){{
  .stats{{grid-template-columns:1fr 1fr}}
  .card-head{{flex-direction:column}}
}}
@media print{{body{{background:#fff;color:#000}}.card{{border:1px solid #ccc}}}}
</style>
</head>
<body>
<div class="wrap">

<header>
  <div class="logo">BUG BOUNTY REPORT</div>
  <h1>Security Assessment<br><span>{esc(target)}</span></h1>
  <div class="meta">Generated {now} &nbsp;·&nbsp; {total} finding{"s" if total!=1 else ""}</div>
</header>

<nav class="nav">{nav_links}</nav>

<div class="stats">{stat_cards}</div>

{sections}

<footer>Generated by Bug Bounty Automation Framework · {now}</footer>
</div>
</body>
</html>"""


# ─────────────────────────────────────────
#  Entry point
# ─────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate an HTML bug bounty report from findings.json",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--findings", required=True, help="Path to findings.json")
    parser.add_argument("--target",   required=True, help="Target domain (e.g. example.com)")
    parser.add_argument("--output",   default="report.html", help="Output HTML path")
    args = parser.parse_args()

    findings = load_findings(args.findings)
    html     = build_html(findings, args.target)

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")

    # stats summary
    groups = group_by_severity(findings)
    print(f"[✓] Report saved → {out_path}")
    print(f"[✓] Total: {len(findings)} findings")
    for sev in ["critical", "high", "medium", "low", "info"]:
        cnt = len(groups.get(sev, []))
        if cnt:
            print(f"    {SEVERITY_EMOJI.get(sev,'')} {sev.capitalize()}: {cnt}")


if __name__ == "__main__":
    main()
